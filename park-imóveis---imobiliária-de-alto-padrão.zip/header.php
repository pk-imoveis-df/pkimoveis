<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-343BLYH990"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-343BLYH990');
    </script>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Descubra imóveis ideais para morar ou investir: opções de casas, apartamentos e imóveis comerciais para comprar, vender ou alugar com a Parkimóveis.">
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <?php wp_head(); ?>
</head>
<body <?php body_class('bg-white text-gray-900'); ?>>

<header class="fixed top-0 w-full z-50 transition-all duration-700 bg-white/95 backdrop-blur-xl border-b border-neutral-100 py-6">
    <div class="container mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="<?php echo home_url(); ?>" class="flex items-center gap-1 group">
            <span class="text-2xl font-display font-black tracking-tighter text-black">
                PARK<span class="font-light ml-1 text-neutral-400">IMÓVEIS</span>
            </span>
        </a>

        <nav class="hidden lg:flex items-center gap-10">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'flex gap-10 text-[10px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400',
                'items_wrap' => '%3$s',
            ));
            ?>
            <a href="<?php echo get_post_type_archive_link('property'); ?>" class="text-[10px] uppercase tracking-[0.4em] font-display font-bold text-black border-b border-black">Portfólio</a>
            <a href="/contato" class="px-10 py-4 bg-black text-white text-[10px] uppercase tracking-[0.4em] font-display font-bold hover:bg-neutral-800 transition-all shadow-xl">Consultoria VIP</a>
        </nav>

        <button class="lg:hidden">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-menu"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
        </button>
    </div>
</header>