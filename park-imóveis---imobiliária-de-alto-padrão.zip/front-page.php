<?php get_header(); ?>

<main>
    <!-- Hero Section -->
    <section class="relative h-screen flex items-center justify-center overflow-hidden">
        <div class="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1920" class="w-full h-full object-cover grayscale-[20%]" alt="Luxury Mansion">
            <div class="absolute inset-0 bg-black/50"></div>
        </div>

        <div class="container mx-auto px-6 relative z-10 text-center text-white">
            <span class="text-[10px] uppercase tracking-[0.6em] font-display font-bold mb-8 block animate-in fade-in slide-in-from-bottom duration-1000">Brasília • Brasil</span>
            <h1 class="text-6xl md:text-9xl font-serif mb-12 leading-none animate-in fade-in slide-in-from-bottom duration-1000 delay-200">Morar é uma Arte.</h1>
            <p class="text-white/60 text-xs md:text-sm uppercase tracking-[0.4em] font-display font-medium mb-16 max-w-2xl mx-auto leading-loose delay-500">Curadoria exclusiva dos ativos imobiliários mais cobiçados do país.</p>
            <div class="flex flex-col md:flex-row gap-6 justify-center">
                <a href="<?php echo get_post_type_archive_link('property'); ?>" class="bg-white text-black px-12 py-6 text-[10px] font-display font-black uppercase tracking-widest shadow-2xl hover:bg-neutral-100 transition-all">Ver Portfólio</a>
                <a href="#leads" class="border-2 border-white/30 text-white px-12 py-6 text-[10px] font-display font-black uppercase tracking-widest backdrop-blur-md hover:bg-white hover:text-black transition-all">Anunciar Imóvel</a>
            </div>
        </div>
    </section>

    <!-- Featured Properties -->
    <section class="py-32 bg-neutral-50">
        <div class="container mx-auto px-6 md:px-12">
            <div class="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
                <div>
                    <span class="text-[10px] uppercase tracking-[0.4em] text-gray-400 font-display font-bold block mb-4">Seleção Especial</span>
                    <h2 class="text-5xl md:text-7xl font-serif leading-tight">Destaques da Temporada</h2>
                </div>
                <a href="<?php echo get_post_type_archive_link('property'); ?>" class="text-[10px] uppercase tracking-widest font-display font-bold border-b-2 border-black pb-2">Explorar Tudo</a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
                <?php
                $args = array(
                    'post_type' => 'property',
                    'posts_per_page' => 3,
                    'meta_query' => array(
                        array('key' => 'property_featured', 'value' => '1')
                    )
                );
                $query = new WP_Query($args);
                if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                    $meta = get_property_meta(get_the_ID());
                ?>
                <article class="group cursor-pointer bg-white overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500">
                    <div class="relative aspect-[4/5] overflow-hidden">
                        <?php the_post_thumbnail('large', array('class' => 'w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110')); ?>
                        <div class="absolute top-6 left-6">
                            <span class="bg-white px-3 py-1 text-[9px] uppercase tracking-widest font-black">EXCLUSIVO</span>
                        </div>
                    </div>
                    <div class="p-10">
                        <span class="text-[9px] uppercase tracking-[0.3em] text-neutral-400 block mb-4"><?php echo $meta['bairro']; ?> • <?php echo $meta['cidade']; ?></span>
                        <h3 class="text-3xl font-serif mb-8 leading-tight group-hover:text-neutral-600 transition-colors"><?php the_title(); ?></h3>
                        <div class="flex justify-between items-center pt-8 border-t border-neutral-100">
                            <span class="text-xl font-serif font-bold"><?php echo number_format($meta['preco'], 2, ',', '.'); ?></span>
                            <a href="<?php the_permalink(); ?>" class="text-[9px] uppercase tracking-widest font-bold text-black border-b border-black">Detalhes</a>
                        </div>
                    </div>
                </article>
                <?php endwhile; wp_reset_postdata(); endif; ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>