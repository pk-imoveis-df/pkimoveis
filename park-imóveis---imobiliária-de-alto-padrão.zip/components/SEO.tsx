
import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  canonical?: string;
  ogType?: string;
  ogImage?: string;
  twitterCard?: string;
}

const SEO: React.FC<SEOProps> = ({
  title,
  description,
  canonical,
  ogType = 'website',
  ogImage,
  twitterCard = 'summary_large_image',
}) => {
  const siteTitle = 'Park Imóveis | Imobiliária de Alto Padrão em Brasília';
  const fullTitle = title ? `${title} | Park Imóveis` : siteTitle;
  const siteDescription = 'Descubra imóveis ideais para morar ou investir: opções de casas, apartamentos e imóveis comerciais para comprar, vender ou alugar com a Parkimóveis.';
  const metaDescription = description || siteDescription;
  const siteUrl = 'https://www.parkimoveis.com.br';
  const fullCanonical = canonical ? `${siteUrl}${canonical}` : siteUrl;
  const defaultImage = 'https://images.unsplash.com/photo-1595861111663-7c3099955401?auto=format&fit=crop&q=80&w=1200';
  const metaImage = ogImage || defaultImage;

  return (
    <Helmet>
      {/* Standard metadata tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDescription} />
      <link rel="canonical" href={fullCanonical} />

      {/* Open Graph tags */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={fullCanonical} />
      <meta property="og:image" content={metaImage} />

      {/* Twitter Card tags */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={metaImage} />
    </Helmet>
  );
};

export default SEO;
