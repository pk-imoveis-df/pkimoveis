
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const CookieConsent: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie-consent', 'true');
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-8 left-8 right-8 md:left-auto md:right-12 md:max-w-md z-[100]"
        >
          <div className="bg-white/95 backdrop-blur-xl p-8 shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-neutral-100 rounded-sm relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-black" />
            
            <button 
              onClick={() => setIsVisible(false)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-black transition-colors"
            >
              <X size={16} />
            </button>

            <div className="space-y-6">
              <h4 className="text-[10px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Privacidade & Cookies</h4>
              <p className="text-xs text-neutral-600 leading-relaxed font-display font-medium">
                Utilizamos cookies para oferecer melhor experiência, melhorar o desempenho, analisar como você interage em nosso site e personalizar conteúdo. Ao utilizar este site, você concorda com o uso de cookies.
              </p>
              <button
                onClick={handleAccept}
                className="w-full bg-black text-white py-4 text-[10px] uppercase tracking-[0.2em] font-display font-medium hover:bg-neutral-800 transition-all rounded-sm shadow-lg"
              >
                Li e aceito os termos
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieConsent;
