
import React, { useState, useEffect } from 'react';
import { Menu, X, Instagram, Facebook, Twitter, Linkedin, Phone, Mail, MapPin, Plus, Check, Lock, User, ArrowRight, Loader2, AlertTriangle, MessageCircle, ChevronUp } from 'lucide-react';
import { optimizeUnsplashUrl } from '../services/imageService';
import { supabase } from '../supabaseClient';
import CookieConsent from './CookieConsent';

interface LayoutProps {
  children: React.ReactNode;
  onNavigate: (page: string) => void;
  currentPage: string;
}

const Layout: React.FC<LayoutProps> = ({ children, onNavigate, currentPage }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [loginTab, setLoginTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);

    // Checar sessão inicial se o supabase estiver disponível
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
      });

      // Ouvir mudanças de auth
      const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        setUser(session?.user ?? null);
      });

      return () => {
        window.removeEventListener('scroll', handleScroll);
        subscription.unsubscribe();
      };
    } else {
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, []);

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'Imóveis', id: 'properties' },
    { name: 'Serviços', id: 'services' },
    { name: 'Quem Somos', id: 'about' },
    { name: 'Contato', id: 'contact' },
  ];

  const handleAdminAccess = () => {
    if (user) {
      onNavigate('admin');
    } else {
      setIsLoginModalOpen(true);
    }
    setIsMenuOpen(false);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) {
      alert("Configuração do Supabase pendente. Verifique o console.");
      return;
    }
    
    setIsSubmitting(true);
    try {
      if (loginTab === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        alert("Verifique seu e-mail para confirmar o cadastro!");
      }
      setIsLoginModalOpen(false);
      onNavigate('admin');
    } catch (err: any) {
      alert(err.message || "Erro na autenticação");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = async () => {
    if (supabase) {
      await supabase.auth.signOut();
      onNavigate('home');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col relative">
      {/* Animated Header */}
      <header
        className={`fixed top-0 w-full z-50 transition-all duration-700 ease-in-out border-b ${
          isScrolled || isMenuOpen 
            ? 'bg-white/98 backdrop-blur-xl shadow-2xl py-4 border-neutral-100' 
            : 'bg-black/10 backdrop-blur-[2px] py-10 border-transparent'
        }`}
      >
        <div className="container mx-auto px-10 flex justify-between items-center">
          <div 
            className="cursor-pointer flex items-center gap-1 group"
            onClick={() => onNavigate('home')}
          >
            <span className={`text-2xl font-display font-black tracking-tighter transition-all duration-500 ${
              isScrolled || isMenuOpen ? 'text-black' : 'text-white'
            }`}>
              PARK<span className={`font-light ml-1 transition-opacity duration-500 ${
                isScrolled || isMenuOpen ? 'text-neutral-400' : 'text-white/80'
              }`}>IMÓVEIS</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-12">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`text-[10px] uppercase tracking-[0.4em] font-display font-bold transition-all duration-300 relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-current after:transition-all hover:after:w-full ${
                  currentPage === link.id
                    ? (isScrolled ? 'text-black after:w-full' : 'text-white after:w-full')
                    : (isScrolled ? 'text-neutral-400 hover:text-black' : 'text-white/60 hover:text-white')
                }`}
              >
                {link.name}
              </button>
            ))}
            
            <button
              onClick={handleAdminAccess}
              className={`flex items-center gap-3 text-[10px] uppercase tracking-[0.4em] font-display font-bold transition-all duration-300 hover:opacity-70 ${
                isScrolled ? 'text-black' : 'text-white'
              }`}
            >
              <Plus size={14} /> Anunciar
            </button>

            {user && (
              <button 
                onClick={handleLogout}
                className="text-[10px] uppercase tracking-[0.4em] font-display font-bold text-red-500 hover:text-red-700 transition-colors"
              >
                Sair
              </button>
            )}

            <button 
              onClick={() => onNavigate('contact')}
              className={`px-10 py-4 text-[10px] uppercase tracking-[0.2em] font-display font-medium transition-all duration-700 rounded-sm shadow-xl transform hover:-translate-y-1 ${
                isScrolled
                  ? 'bg-black text-white hover:bg-neutral-800'
                  : 'bg-white text-black hover:bg-neutral-100 border-none'
              }`}
            >
              Consultoria VIP
            </button>
          </nav>

          {/* Mobile Toggle */}
          <button
            className="lg:hidden p-3 rounded-full hover:bg-neutral-100 transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X size={24} className="text-black" />
            ) : (
              <Menu size={24} className={isScrolled ? 'text-black' : 'text-white'} />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`lg:hidden absolute top-full left-0 w-full bg-white shadow-2xl transition-all duration-700 ease-in-out overflow-hidden ${isMenuOpen ? 'max-h-screen border-t border-neutral-100' : 'max-h-0'}`}>
          <div className="py-16 px-10 flex flex-col gap-10 items-center">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setIsMenuOpen(false);
                }}
                className={`text-xs uppercase tracking-[0.5em] font-display font-bold transition-colors ${
                  currentPage === link.id ? 'text-black' : 'text-neutral-400 hover:text-black'
                }`}
              >
                {link.name}
              </button>
            ))}
            <button
                onClick={handleAdminAccess}
                className="text-xs uppercase tracking-[0.5em] font-display font-bold text-neutral-400 hover:text-black flex items-center gap-3"
              >
              <Plus size={18} /> Anunciar Imóvel
            </button>
            <button 
              onClick={() => {
                onNavigate('contact');
                setIsMenuOpen(false);
              }}
              className="w-full mt-10 py-6 bg-black text-white uppercase tracking-[0.5em] font-display font-bold text-xs shadow-2xl rounded-sm"
            >
              Solicitar Orçamento
            </button>
          </div>
        </div>
      </header>

      {/* Login Modal */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-md animate-in fade-in duration-500" onClick={() => setIsLoginModalOpen(false)} />
          <div className="relative bg-white w-full max-w-lg overflow-hidden rounded-sm shadow-2xl animate-in zoom-in-95 duration-500">
            {/* Header Modal */}
            <div className="flex border-b border-neutral-100">
              <button 
                onClick={() => setLoginTab('login')}
                className={`flex-1 py-6 text-[10px] uppercase tracking-[0.4em] font-display font-bold transition-all ${
                  loginTab === 'login' ? 'bg-white text-black' : 'bg-neutral-50 text-neutral-400'
                }`}
              >
                Acesso Corretor
              </button>
              <button 
                onClick={() => setLoginTab('register')}
                className={`flex-1 py-6 text-[10px] uppercase tracking-[0.4em] font-display font-bold transition-all ${
                  loginTab === 'register' ? 'bg-white text-black' : 'bg-neutral-50 text-neutral-400'
                }`}
              >
                Seja Parceiro
              </button>
              <button 
                onClick={() => setIsLoginModalOpen(false)}
                className="px-8 bg-neutral-50 text-neutral-400 hover:text-black transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-16">
              {!supabase && (
                <div className="mb-10 p-6 bg-amber-50 border border-amber-100 flex gap-4 rounded-sm">
                  <AlertTriangle className="text-amber-500 shrink-0" size={20} />
                  <p className="text-[10px] text-amber-800 font-display font-bold uppercase tracking-wider leading-relaxed">
                    Nota: O backend (Supabase) não está configurado. O sistema de login está desabilitado no momento.
                  </p>
                </div>
              )}

              <div className="text-center mb-14">
                <h3 className="text-4xl font-serif mb-4 leading-tight">
                  {loginTab === 'login' ? 'Portal Park Imóveis' : 'Novo Credenciamento'}
                </h3>
                <p className="text-neutral-400 text-[9px] uppercase tracking-[0.5em] font-display font-bold">
                  {loginTab === 'login' ? 'Gestão de Ativos de Luxo' : 'Expanda seu Portfólio Conosco'}
                </p>
              </div>

              <form className={`space-y-8 ${!supabase ? 'opacity-50 pointer-events-none' : ''}`} onSubmit={handleLoginSubmit}>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] text-neutral-400 font-display font-bold">Identificação (E-mail)</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-0 top-1/2 -translate-y-1/2 text-neutral-300" />
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-8 py-4 border-b border-neutral-100 focus:border-black outline-none transition-all text-sm font-display font-medium"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] text-neutral-400 font-display font-bold">Chave de Acesso (Senha)</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-0 top-1/2 -translate-y-1/2 text-neutral-300" />
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-8 py-4 border-b border-neutral-100 focus:border-black outline-none transition-all text-sm font-display font-medium"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={isSubmitting || !supabase}
                  className="w-full bg-black text-white py-6 flex items-center justify-center gap-4 uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-neutral-800 transition-all shadow-2xl transform hover:-translate-y-1"
                >
                  {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : (loginTab === 'login' ? 'Autenticar Sistema' : 'Solicitar Cadastro')}
                  <ArrowRight size={16} />
                </button>
              </form>

              <p className="mt-12 text-[9px] text-center text-neutral-300 leading-loose uppercase tracking-widest max-w-xs mx-auto">
                Área restrita. O acesso não autorizado é monitorado conforme nossa política de compliance.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Back to Top Button */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-32 right-8 z-[60] bg-white text-black p-4 rounded-full shadow-2xl border border-neutral-100 transition-all duration-500 transform hover:-translate-y-2 ${
          showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'
        }`}
        aria-label="Voltar ao topo"
      >
        <ChevronUp size={24} />
      </button>

      {/* WhatsApp Floating Button */}
      <a 
        href="https://wa.me/5561996587308" 
        target="_blank" 
        rel="noopener noreferrer"
        aria-label="Fale conosco no WhatsApp"
        className="fixed bottom-8 right-8 z-[60] bg-[#25D366] text-white p-5 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 group"
      >
        <div className="absolute inset-0 bg-[#25D366] rounded-full animate-ping opacity-20 group-hover:opacity-0 transition-opacity" />
        <MessageCircle size={28} className="relative z-10" />
        <span className="absolute right-full mr-4 bg-white text-black px-4 py-2 rounded-sm text-[10px] font-display font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity shadow-lg pointer-events-none whitespace-nowrap border border-neutral-100">
          Atendimento Direto
        </span>
      </a>

      {/* Footer */}
      <footer className="relative bg-black text-white overflow-hidden">
        <div className="container mx-auto px-12 py-24 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-20">
            
            <div className="space-y-8">
              <h3 className="text-[11px] uppercase tracking-[0.4em] font-display font-bold text-white">CONTATO CORPORATIVO</h3>
              <div className="space-y-5 text-[13px] font-display text-neutral-200 leading-relaxed tracking-wide">
                <p>Águas Claras Shopping, Salas 306 e 307 — DF</p>
                <p>contato@parkimoveis.com.br</p>
                <p>61. 9.9658-7308</p>
                <div className="pt-8 text-[10px] font-semibold text-neutral-400 uppercase tracking-widest leading-loose">
                  PARK IMÓVEIS Administradora LTDA<br />
                  CNPJ: 55.234.293/0001-63
                </div>
              </div>
              <div className="flex gap-6 pt-6 text-neutral-300">
                <a href="https://facebook.com/parkimoveis" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors"><Facebook size={20} strokeWidth={1.5} /></a>
                <a href="https://twitter.com/parkimoveis" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors"><Twitter size={20} strokeWidth={1.5} /></a>
                <a href="https://www.instagram.com/parkimoveisbrasilia/#" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors"><Instagram size={20} strokeWidth={1.5} /></a>
                <a href="https://www.linkedin.com/company/park-imoveis-brasilia/?viewAsMember=true" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors"><Linkedin size={20} strokeWidth={1.5} /></a>
              </div>
            </div>

            <div className="space-y-8">
              <h3 className="text-[10px] uppercase tracking-[0.4em] font-display font-bold text-neutral-500 mb-8">NAVEGAÇÃO RÁPIDA</h3>
              <ul className="space-y-4 text-[10px] font-display font-medium text-neutral-400 uppercase tracking-[0.2em]">
                <li>
                  <button onClick={() => onNavigate('home')} className="hover:text-white transition-colors">Home</button>
                </li>
                <li>
                  <button onClick={() => onNavigate('properties')} className="hover:text-white transition-colors">Imóveis</button>
                </li>
                <li>
                  <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors">Serviços</button>
                </li>
                <li>
                  <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors">Quem Somos</button>
                </li>
                <li>
                  <button onClick={() => onNavigate('contact')} className="hover:text-white transition-colors">Contato</button>
                </li>
                <li>
                  <button onClick={handleAdminAccess} className="hover:text-white transition-colors">Área do Consultor</button>
                </li>
              </ul>
            </div>

            <div className="space-y-8">
              <h3 className="text-[11px] uppercase tracking-[0.4em] font-display font-bold text-white">CIRCULAR EXCLUSIVA</h3>
              <p className="text-[11px] font-display text-neutral-300 leading-relaxed uppercase tracking-widest">
                Assine para receber convites para vernissages e pré-lançamentos off-market.
              </p>
              <form className="space-y-5 pt-4" onSubmit={(e) => e.preventDefault()}>
                <input 
                  type="email" 
                  placeholder="SEU EMAIL PROFISSIONAL"
                  className="w-full bg-neutral-900 text-neutral-200 py-4 px-6 text-[10px] font-display font-bold focus:outline-none placeholder:text-neutral-600 border border-neutral-800 focus:border-neutral-600 transition-all rounded-sm"
                />
                <button className="w-full bg-neutral-800 text-white py-5 text-[10px] font-display font-medium uppercase tracking-[0.2em] hover:bg-neutral-700 transition-colors shadow-2xl rounded-sm">
                  ASSINAR
                </button>
              </form>
            </div>

          </div>
          
          <div className="mt-24 pt-10 border-t border-neutral-900/50 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-[10px] text-neutral-500 uppercase tracking-[0.4em]">© 2024 Park Imóveis — Todos os direitos reservados.</p>
            <p className="text-[10px] text-neutral-500 uppercase tracking-[0.4em]">Design by <a href="https://www.minth.com.br" target="_blank" rel="noopener noreferrer" className="text-neutral-200 hover:text-white transition-colors">AGE MINTH</a></p>
          </div>
        </div>
      </footer>
      <CookieConsent />
    </div>
  );
};

export default Layout;
