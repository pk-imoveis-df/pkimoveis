
import React from 'react';
import { Property } from '../types';
import { MapPin, Maximize, BedDouble, Bath } from 'lucide-react';
import { optimizeUnsplashUrl } from '../services/imageService';

interface PropertyCardProps {
  property: Property;
  onClick: (id: string) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onClick }) => {
  const formattedPrice = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(property.price);

  return (
    <div 
      className="group cursor-pointer bg-white overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-2 hover:scale-[1.02] transition-all duration-500 ease-out"
      onClick={() => onClick(property.id)}
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={optimizeUnsplashUrl(property.mainImage, 600)} 
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
          decoding="async"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <span className="bg-white/90 backdrop-blur px-3 py-1 text-[10px] uppercase tracking-widest font-bold">
            {property.status}
          </span>
          {property.featured && (
            <span className="bg-black text-white px-3 py-1 text-[10px] uppercase tracking-widest font-bold">
              Destaque
            </span>
          )}
        </div>
        <div className="absolute bottom-0 left-0 w-full p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-500 bg-gradient-to-t from-black/80 to-transparent">
           <button className="w-full py-3 bg-white text-black text-xs uppercase tracking-widest font-bold hover:bg-gray-100 transition-colors">
            Ver Detalhes
           </button>
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <div className="flex flex-col">
            <span className="text-[9px] text-neutral-400 font-bold uppercase tracking-widest mb-1">Cód: {property.code}</span>
            <span className="text-xs text-gray-400 uppercase tracking-widest">{property.type}</span>
          </div>
          <span className="text-lg font-serif font-bold">{formattedPrice}</span>
        </div>
        <h3 className="text-xl font-serif mb-4 line-clamp-1">{property.title}</h3>
        
        <div className="flex items-center gap-2 text-gray-500 mb-6">
          <MapPin size={14} />
          <span className="text-sm">{property.region}, {property.city}</span>
        </div>

        <div className="grid grid-cols-3 border-t border-gray-100 pt-4">
          <div className="flex flex-col items-center border-r border-gray-100">
            <div className="flex items-center gap-1 text-gray-400 mb-1">
              <Maximize size={14} />
              <span className="text-[10px] uppercase tracking-tighter">Área</span>
            </div>
            <span className="text-sm font-medium">{property.area}m²</span>
          </div>
          <div className="flex flex-col items-center border-r border-gray-100">
            <div className="flex items-center gap-1 text-gray-400 mb-1">
              <BedDouble size={14} />
              <span className="text-[10px] uppercase tracking-tighter">Quartos</span>
            </div>
            <span className="text-sm font-medium">{property.bedrooms}</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1 text-gray-400 mb-1">
              <Bath size={14} />
              <span className="text-[10px] uppercase tracking-tighter">Banh</span>
            </div>
            <span className="text-sm font-medium">{property.bathrooms}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
