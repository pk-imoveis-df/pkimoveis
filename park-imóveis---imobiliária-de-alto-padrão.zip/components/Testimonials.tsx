
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { optimizeUnsplashUrl } from '../services/imageService';

interface Testimonial {
  id: number;
  name: string;
  role?: string;
  avatar: string;
  time: string;
  rating: number;
  text: string;
  verified: boolean;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Rafaela Siqueira",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
    time: "7 meses atrás",
    rating: 5,
    text: "Contratei e virei fã número 1 do trabalho da Park Imóveis. São incríveis desde o primeiro contato. Tiraram todas as minhas dúvidas e principalmente meu medo de investir em imóveis de alto padrão.",
    verified: true
  },
  {
    id: 2,
    name: "Aline de Souza Medeiros",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150",
    time: "7 meses atrás",
    rating: 5,
    text: "Olá! Sou investidora e recomendo a Park Imóveis de olhos fechados. Sou exigente com prazos e documentação e eles me acolheram tão bem. O atendimento é realmente diferenciado.",
    verified: true
  },
  {
    id: 3,
    name: "Leticia de Lima",
    avatar: "L", // Initial
    time: "7 meses atrás",
    rating: 5,
    text: "Sensacional, as opções de casas aqui no Lago Sul são maravilhosas. Depois de contratarmos vocês, encontramos o imóvel dos nossos sonhos em tempo recorde. Indico com toda certeza!",
    verified: true
  },
  {
    id: 4,
    name: "Ricardo Mendes",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
    time: "3 meses atrás",
    rating: 5,
    text: "Excelente consultoria. O processo de compra foi extremamente transparente e profissional. A equipe da Park Imóveis realmente entende o mercado de luxo em Brasília.",
    verified: true
  }
];

const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const next = useCallback(() => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  }, []);

  const prev = useCallback(() => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  }, []);

  useEffect(() => {
    const timer = setInterval(next, 8000);
    return () => clearInterval(timer);
  }, [next]);

  // For desktop, we want to show 3 items. 
  // We can calculate the indices to show.
  const getVisibleIndices = () => {
    const indices = [];
    for (let i = 0; i < 3; i++) {
      indices.push((currentIndex + i) % testimonials.length);
    }
    return indices;
  };

  const visibleIndices = getVisibleIndices();

  return (
    <section className="py-32 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-serif mb-4 text-[#1a2b3c]">Depoimentos</h2>
          <p className="text-neutral-600 font-display text-lg">O que nossos clientes dizem...</p>
        </div>

        <div className="relative max-w-7xl mx-auto">
          {/* Carousel Container */}
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <AnimatePresence initial={false} mode="popLayout">
                {visibleIndices.map((idx, i) => (
                  <motion.div
                    key={`${testimonials[idx].id}-${i}`}
                    initial={{ opacity: 0, x: direction > 0 ? 50 : -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: direction > 0 ? -50 : 50 }}
                    transition={{ duration: 0.5, ease: "easeInOut" }}
                    className={i === 2 ? "hidden lg:block" : i === 1 ? "hidden md:block" : ""}
                  >
                    <TestimonialCard testimonial={testimonials[idx]} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* Navigation Arrows - Positioned like in the image */}
            <button 
              onClick={prev}
              className="absolute top-1/2 -left-6 md:-left-12 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center text-neutral-400 hover:text-black hover:scale-110 transition-all z-20 border border-neutral-100"
            >
              <ChevronLeft size={24} />
            </button>
            <button 
              onClick={next}
              className="absolute top-1/2 -right-6 md:-right-12 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center text-neutral-400 hover:text-black hover:scale-110 transition-all z-20 border border-neutral-100"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Pagination Dots */}
          <div className="flex justify-center mt-12 gap-2">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setDirection(idx > currentIndex ? 1 : -1);
                  setCurrentIndex(idx);
                }}
                className={`w-2 h-2 rounded-full transition-all ${
                  idx === currentIndex ? 'bg-black w-6' : 'bg-neutral-200'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
  return (
    <div className="bg-[#f8f9fa] p-10 rounded-2xl shadow-sm border border-neutral-100 h-full flex flex-col relative group hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-6">
        <div className="flex gap-4 items-center">
          {typeof testimonial.avatar === 'string' && testimonial.avatar.length > 1 ? (
            <img 
              src={optimizeUnsplashUrl(testimonial.avatar, 150)} 
              alt={testimonial.name} 
              className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-sm"
              loading="lazy"
              decoding="async"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-[#689f38] flex items-center justify-center text-white font-bold text-2xl shadow-sm">
              {testimonial.avatar}
            </div>
          )}
          <div>
            <h4 className="font-bold text-[#0a1629] text-lg leading-tight">{testimonial.name}</h4>
            <span className="text-sm text-neutral-400 font-medium">{testimonial.time}</span>
          </div>
        </div>
        <div className="w-6 h-6">
          <svg viewBox="0 0 24 24" className="w-full h-full">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
        </div>
      </div>

      <div className="flex gap-1 mb-6 items-center">
        {[...Array(5)].map((_, i) => (
          <Star key={i} size={20} className="fill-[#ffc107] text-[#ffc107]" />
        ))}
        {testimonial.verified && (
          <div className="ml-2 bg-[#4285f4] rounded-full p-0.5 flex items-center justify-center">
            <CheckCircle2 size={14} className="text-white fill-white" />
          </div>
        )}
      </div>

      <p className="text-[#0a1629] text-base leading-relaxed mb-8 flex-grow font-medium">
        {testimonial.text}
      </p>

      <a href="#" className="text-sm font-bold text-neutral-400 hover:text-black transition-colors">
        Consulte Mais informação
      </a>
    </div>
  );
};

export default Testimonials;
