
export interface Property {
  id: string;
  code: string;
  title: string;
  description: string;
  price: number;
  type: 'Casa' | 'Apartamento' | 'Cobertura' | 'Terreno' | 'Mansão';
  status: 'Venda' | 'Aluguel';
  city: string;
  state: string;
  region: string;
  address: string;
  area: number;
  bedrooms: number;
  bathrooms: number;
  parkingSpots: number;
  mainImage: string;
  gallery: string[];
  createdAt: string;
  featured: boolean;
  lat?: number;
  lng?: number;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  propertyId?: string;
  date: string;
}

export interface SearchFilters {
  type: string;
  minPrice: number;
  maxPrice: number;
  location: string;
  city: string;
  state: string;
  bedrooms?: number;
  bathrooms?: number;
  parkingSpots?: number;
}
