<footer class="bg-black text-white pt-32 pb-16">
    <div class="container mx-auto px-6 md:px-12">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-24 mb-32">
            <div class="space-y-10">
                <span class="text-2xl font-display font-black tracking-tighter">PARK<span class="font-light ml-1 text-neutral-600">IMÓVEIS</span></span>
                <p class="text-neutral-500 text-sm leading-relaxed max-w-sm font-light">Especialistas em ativos imobiliários de alto padrão em Brasília e regiões metropolitanas. Atendimento sob medida para investidores e famílias exigentes.</p>
            </div>
            
            <div class="space-y-8">
                <h4 class="text-[10px] uppercase tracking-[0.5em] font-display font-bold text-neutral-300">CONTATO</h4>
                <div class="space-y-4 text-sm text-neutral-500">
                    <p>Águas Claras Shopping, Salas 306/307 — DF</p>
                    <p>+55 (61) 9.9658-7308</p>
                    <p>contato@parkimoveis.com.br</p>
                </div>
            </div>

            <div class="space-y-8">
                <h4 class="text-[10px] uppercase tracking-[0.5em] font-display font-bold text-neutral-300">NEWSLETTER</h4>
                <form class="flex border-b border-neutral-800 pb-2">
                    <input type="email" placeholder="SEU E-MAIL" class="bg-transparent text-[10px] uppercase tracking-widest font-bold w-full outline-none">
                    <button class="text-[10px] font-bold tracking-widest">OK</button>
                </form>
            </div>
        </div>

        <div class="pt-10 border-t border-neutral-900 flex flex-col md:flex-row justify-between items-center gap-6">
            <p class="text-[9px] text-neutral-600 uppercase tracking-[0.3em]">© <?php echo date('Y'); ?> Park Imóveis. Todos os direitos reservados.</p>
            <div class="flex gap-10 text-[9px] text-neutral-600 uppercase tracking-[0.3em]">
                <a href="#">Privacidade</a>
                <a href="#">Compliance</a>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>