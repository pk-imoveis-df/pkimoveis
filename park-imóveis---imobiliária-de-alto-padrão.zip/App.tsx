
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Home from './pages/Home';
import Properties from './pages/Properties';
import PropertyDetail from './pages/PropertyDetail';
import Services from './pages/Services';
import About from './pages/About';
import Contact from './pages/Contact';
import Admin from './pages/Admin';
import { Property, SearchFilters } from './types';
import { supabase } from './supabaseClient';
import { propertyService } from './services/propertyService';
import { MOCK_PROPERTIES } from './db';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [activeFilters, setActiveFilters] = useState<SearchFilters | undefined>(undefined);
  const [allProperties, setAllProperties] = useState<Property[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [contactMapAddress, setContactMapAddress] = useState<string | null>(null);

  const fetchProperties = async () => {
    setIsLoading(true);
    try {
      if (!supabase) {
        setAllProperties(MOCK_PROPERTIES);
      } else {
        const data = await propertyService.getAll();
        setAllProperties(data.length > 0 ? data : MOCK_PROPERTIES);
      }
    } catch (err) {
      console.error("Erro ao carregar imóveis:", err);
      setAllProperties(MOCK_PROPERTIES);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();

    let subscription: any = null;
    if (supabase) {
      subscription = supabase
        .channel('public:properties')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'properties' }, () => {
          fetchProperties();
        })
        .subscribe();
    }

    return () => {
      if (supabase && subscription) {
        supabase.removeChannel(subscription);
      }
    };
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage, selectedPropertyId]);

  const navigateTo = (page: string) => {
    setCurrentPage(page);
    setSelectedPropertyId(null);
    setActiveFilters(undefined);
    setContactMapAddress(null);
  };

  const selectProperty = (id: string) => {
    setSelectedPropertyId(id);
    setCurrentPage('property-detail');
  };

  const navigateToPropertiesWithFilters = (filters?: SearchFilters) => {
    setActiveFilters(filters);
    setCurrentPage('properties');
    setSelectedPropertyId(null);
  };

  const navigateToContactWithLocation = (address: string) => {
    setContactMapAddress(address);
    setCurrentPage('contact');
    setSelectedPropertyId(null);
  };

  const renderPage = () => {
    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-white">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-black border-t-transparent rounded-full animate-spin"></div>
            <span className="text-[10px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Carregando Portfólio...</span>
          </div>
        </div>
      );
    }

    if (selectedPropertyId && currentPage === 'property-detail') {
      const property = allProperties.find(p => p.id === selectedPropertyId);
      if (property) {
        return (
          <PropertyDetail 
            property={property} 
            onBack={() => setCurrentPage('properties')} 
            onViewLocation={navigateToContactWithLocation}
          />
        );
      }
    }

    switch (currentPage) {
      case 'home':
        return (
          <Home 
            properties={allProperties} 
            onSelectProperty={selectProperty} 
            onNavigateToProperties={navigateToPropertiesWithFilters}
            onNavigate={navigateTo}
          />
        );
      case 'properties':
        return (
          <Properties 
            properties={allProperties} 
            onSelectProperty={selectProperty}
            onNavigate={navigateTo}
            initialFilters={activeFilters}
          />
        );
      case 'services':
        return <Services onNavigate={navigateTo} />;
      case 'about':
        return <About onNavigate={navigateTo} />;
      case 'contact':
        return <Contact initialAddress={contactMapAddress} />;
      case 'admin':
        return <Admin onAddProperty={() => navigateTo('properties')} />;
      default:
        return <Home 
          properties={allProperties} 
          onSelectProperty={selectProperty} 
          onNavigateToProperties={navigateToPropertiesWithFilters}
          onNavigate={navigateTo}
        />;
    }
  };

  return (
    <Layout onNavigate={navigateTo} currentPage={currentPage}>
      {renderPage()}
    </Layout>
  );
};

export default App;
