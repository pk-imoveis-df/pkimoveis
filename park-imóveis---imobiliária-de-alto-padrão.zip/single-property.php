<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); 
    $meta = get_property_meta(get_the_ID());
?>
<main class="pt-24 bg-white min-h-screen">
    <div class="container mx-auto px-6 md:px-12 py-20">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-24 items-start">
            
            <!-- Gallery & Info -->
            <div class="space-y-16">
                <div class="aspect-[4/5] bg-neutral-100 overflow-hidden shadow-2xl">
                    <?php the_post_thumbnail('full', array('class' => 'w-full h-full object-cover')); ?>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-12 py-10 border-y border-neutral-100">
                    <div class="space-y-2">
                        <span class="text-[9px] uppercase tracking-widest font-bold text-neutral-400">Área</span>
                        <p class="text-2xl font-serif"><?php echo $meta['area']; ?>m²</p>
                    </div>
                    <div class="space-y-2">
                        <span class="text-[9px] uppercase tracking-widest font-bold text-neutral-400">Suítes</span>
                        <p class="text-2xl font-serif"><?php echo $meta['quartos']; ?></p>
                    </div>
                    <div class="space-y-2">
                        <span class="text-[9px] uppercase tracking-widest font-bold text-neutral-400">Banh</span>
                        <p class="text-2xl font-serif"><?php echo $meta['banheiros']; ?></p>
                    </div>
                    <div class="space-y-2">
                        <span class="text-[9px] uppercase tracking-widest font-bold text-neutral-400">Vagas</span>
                        <p class="text-2xl font-serif"><?php echo $meta['vagas']; ?></p>
                    </div>
                </div>
            </div>

            <!-- Description & Form -->
            <div class="space-y-12">
                <header>
                    <span class="text-[10px] uppercase tracking-[0.4em] text-neutral-400 block mb-6"><?php echo $meta['bairro']; ?></span>
                    <h1 class="text-5xl md:text-7xl font-serif mb-10 leading-none"><?php the_title(); ?></h1>
                    <div class="text-4xl font-serif text-black border-l-4 border-black pl-8 my-10">
                        R$ <?php echo number_format($meta['preco'], 2, ',', '.'); ?>
                    </div>
                </header>

                <div class="prose prose-xl text-neutral-600 leading-relaxed font-light">
                    <?php the_content(); ?>
                </div>

                <div class="bg-neutral-50 p-12 border border-neutral-100">
                    <h3 class="text-2xl font-serif mb-8">Agendar Atendimento</h3>
                    <form id="schedule-form" class="space-y-6">
                        <div class="space-y-2">
                            <input id="form-name" type="text" placeholder="NOME COMPLETO" class="w-full bg-white border border-neutral-100 p-5 text-[10px] uppercase tracking-widest font-bold outline-none focus:border-black transition-all">
                            <span id="name-error" class="text-[9px] text-red-500 font-bold uppercase tracking-tighter hidden">O nome deve ter pelo menos 3 caracteres.</span>
                        </div>
                        <div class="space-y-2">
                            <input id="form-email" type="email" placeholder="E-MAIL CORPORATIVO" class="w-full bg-white border border-neutral-100 p-5 text-[10px] uppercase tracking-widest font-bold outline-none focus:border-black transition-all">
                            <span id="email-error" class="text-[9px] text-red-500 font-bold uppercase tracking-tighter hidden">Por favor, insira um e-mail válido.</span>
                        </div>
                        <button type="submit" class="w-full bg-black text-white py-6 text-[10px] uppercase tracking-widest font-bold shadow-2xl hover:bg-neutral-800 transition-all">SOLICITAR DOSSIÊ COMPLETO</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const nameInput = document.getElementById('form-name');
    const emailInput = document.getElementById('form-email');
    const nameError = document.getElementById('name-error');
    const emailError = document.getElementById('email-error');
    const form = document.getElementById('schedule-form');

    const validateName = (val) => val.trim().length >= 3;
    const validateEmail = (val) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);

    nameInput?.addEventListener('input', (e) => {
        const val = e.target.value;
        if (val.trim() === '') {
            nameError.classList.add('hidden');
            nameInput.classList.remove('border-red-500');
            return;
        }
        if (validateName(val)) {
            nameError.classList.add('hidden');
            nameInput.classList.remove('border-red-500');
            nameInput.classList.add('border-green-500');
        } else {
            nameError.classList.remove('hidden');
            nameInput.classList.add('border-red-500');
            nameInput.classList.remove('border-green-500');
        }
    });

    emailInput?.addEventListener('input', (e) => {
        const val = e.target.value;
        if (val.trim() === '') {
            emailError.classList.add('hidden');
            emailInput.classList.remove('border-red-500');
            return;
        }
        if (validateEmail(val)) {
            emailError.classList.add('hidden');
            emailInput.classList.remove('border-red-500');
            emailInput.classList.add('border-green-500');
        } else {
            emailError.classList.remove('hidden');
            emailInput.classList.add('border-red-500');
            emailInput.classList.remove('border-green-500');
        }
    });

    form?.addEventListener('submit', (e) => {
        const isNameValid = validateName(nameInput.value);
        const isEmailValid = validateEmail(emailInput.value);
        
        if (!isNameValid || !isEmailValid) {
            e.preventDefault();
            if (!isNameValid) {
                nameError.classList.remove('hidden');
                nameInput.classList.add('border-red-500');
            }
            if (!isEmailValid) {
                emailError.classList.remove('hidden');
                emailInput.classList.add('border-red-500');
            }
            alert('Por favor, preencha os campos corretamente antes de enviar.');
        } else {
            // Em um tema real, aqui você enviaria via AJAX ou action do WP
            e.preventDefault();
            alert('Obrigado! Sua solicitação foi enviada com sucesso (simulação).');
            form.reset();
            nameInput.classList.remove('border-green-500');
            emailInput.classList.remove('border-green-500');
        }
    });
});
</script>

<?php endwhile; endif; ?>

<?php get_footer(); ?>