
-- ESQUEMA DE ALTO PADRÃO PARK IMÓVEIS (SUPABASE)

-- 1. TABELA DE IMÓVEIS
CREATE TABLE IF NOT EXISTS public.properties (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code TEXT UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    type TEXT CHECK (type IN ('Casa', 'Apartamento', 'Cobertura', 'Terreno', 'Mansão')),
    status TEXT CHECK (status IN ('Venda', 'Aluguel')),
    city TEXT,
    state TEXT,
    region TEXT,
    address TEXT,
    area NUMERIC,
    bedrooms INTEGER,
    bathrooms INTEGER,
    parking_spots INTEGER,
    main_image TEXT,
    gallery TEXT[] DEFAULT '{}',
    featured BOOLEAN DEFAULT FALSE,
    lat NUMERIC,
    lng NUMERIC,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. TABELA DE SOLICITAÇÕES (LEADS)
CREATE TABLE IF NOT EXISTS public.inquiries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    message TEXT,
    property_id UUID REFERENCES public.properties(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. HABILITAR SEGURANÇA DE LINHA (RLS)
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

-- 4. POLÍTICAS PARA IMÓVEIS (PROPERTIES)
-- Público: Apenas leitura
CREATE POLICY "Leitura pública de imóveis" ON public.properties 
    FOR SELECT USING (true);

-- Corretores (Autenticados): Criar, Editar e Excluir
CREATE POLICY "Inserção para corretores" ON public.properties 
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Atualização para corretores" ON public.properties 
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Exclusão para corretores" ON public.properties 
    FOR DELETE USING (auth.role() = 'authenticated');

-- 5. POLÍTICAS PARA SOLICITAÇÕES (INQUIRIES / LEADS)
-- Público: Apenas enviar mensagens (INSERT)
CREATE POLICY "Envio público de leads" ON public.inquiries 
    FOR INSERT WITH CHECK (true);

-- Corretores (Autenticados): Ver e Excluir leads (NÃO podem editar mensagens de clientes)
CREATE POLICY "Leitura de leads para corretores" ON public.inquiries 
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Exclusão de leads para corretores" ON public.inquiries 
    FOR DELETE USING (auth.role() = 'authenticated');

-- 6. CONFIGURAÇÃO DE STORAGE (BUCKET 'properties')
-- Criar o bucket se não existir
INSERT INTO storage.buckets (id, name, "public")
VALUES ('properties', 'properties', true)
ON CONFLICT (id) DO NOTHING;

-- Políticas de Storage Refinadas
CREATE POLICY "Imagens públicas" ON storage.objects
    FOR SELECT USING (bucket_id = 'properties');

CREATE POLICY "Upload para corretores" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'properties' AND auth.role() = 'authenticated');

CREATE POLICY "Atualização para corretores" ON storage.objects
    FOR UPDATE USING (bucket_id = 'properties' AND auth.role() = 'authenticated');

CREATE POLICY "Exclusão para corretores" ON storage.objects
    FOR DELETE USING (bucket_id = 'properties' AND auth.role() = 'authenticated');
