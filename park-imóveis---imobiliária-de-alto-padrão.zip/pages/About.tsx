
import React from 'react';
import SEO from '../components/SEO';
import { optimizeUnsplashUrl } from '../services/imageService';

interface AboutProps {
  onNavigate: (page: string) => void;
}

const About: React.FC<AboutProps> = ({ onNavigate }) => {
  return (
    <div className="pt-24 bg-white min-h-screen">
      <SEO 
        title="Sobre Nós" 
        description="Conheça a história da Park Imóveis, a imobiliária que está redefinindo o mercado de luxo em Brasília com exclusividade e sofisticação."
        canonical="/sobre"
      />
      <section className="py-24 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center mb-24">
          <span className="text-[10px] uppercase tracking-[0.3em] text-gray-400 font-bold block mb-6">Nossa História</span>
          <h1 className="text-5xl md:text-7xl font-serif mb-12">Paixão pela Arquitetura e Compromisso com o Luxo.</h1>
          <p className="text-xl text-gray-500 leading-relaxed">
            Fundada em 2020, a Park Imóveis nasceu de uma lacuna no mercado: a falta de um atendimento que compreendesse o imóvel não apenas como um ativo, mas como um estilo de vida.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
          <div>
            <img 
              src={optimizeUnsplashUrl("https://images.unsplash.com/photo-1582407947304-fd86f028f716", 1200)} 
              alt="Arquitetura" 
              className="w-full aspect-square object-cover"
              loading="lazy"
              decoding="async"
            />
          </div>
          <div className="space-y-12">
            <div>
              <h3 className="text-2xl font-serif mb-4">Nossa Missão</h3>
              <p className="text-gray-500 leading-relaxed">Conectar pessoas extraordinárias a imóveis excepcionais, proporcionando uma experiência de transação fluida, segura e memorável.</p>
            </div>
            <div>
              <h3 className="text-2xl font-serif mb-4">Nossa Visão</h3>
              <p className="text-gray-500 leading-relaxed">Ser a referência nacional em curadoria imobiliária de luxo, reconhecida pela ética inabalável e excelência no portfólio.</p>
            </div>
            <div>
              <h3 className="text-2xl font-serif mb-4">Nossos Valores</h3>
              <ul className="grid grid-cols-2 gap-4">
                {['Discrição Absoluta', 'Excelência Técnica', 'Transparência Total', 'Curadoria Rigorosa'].map((v, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest border border-gray-100 p-4">
                    <div className="w-1.5 h-1.5 bg-black" />
                    {v}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-black text-white py-32">
        <div className="container mx-auto px-6 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 mb-20">
            <div>
              <div className="text-6xl font-serif mb-2">6+</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-gray-400">Anos de Mercado</div>
            </div>
            <div>
              <div className="text-6xl font-serif mb-2">2.5B</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-gray-400">Em Vendas (VGV)</div>
            </div>
            <div>
              <div className="text-6xl font-serif mb-2">150+</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-gray-400">Imóveis Exclusivos</div>
            </div>
            <div>
              <div className="text-6xl font-serif mb-2">98%</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-gray-400">Satisfação</div>
            </div>
          </div>
          <button 
            onClick={() => onNavigate('contact')}
            className="px-16 py-6 bg-white text-black text-[10px] font-display font-medium uppercase tracking-[0.2em] hover:bg-neutral-100 transition-all rounded-sm shadow-2xl"
          >
            Trabalhe Conosco
          </button>
        </div>
      </section>
    </div>
  );
};

export default About;
