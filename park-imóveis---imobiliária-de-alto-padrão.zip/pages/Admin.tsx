
import React, { useState, useRef, useEffect } from 'react';
import { Property } from '../types';
import { Camera, MapPin, DollarSign, Layout as LayoutIcon, CheckCircle2, ArrowRight, Upload, X, Image as ImageIcon, Loader2, Database, AlertCircle, MessageSquare, PlusCircle, Calendar, User, Phone, Mail, Trash2 } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { propertyService } from '../services/propertyService';

interface AdminProps {
  onAddProperty: () => void;
}

const Admin: React.FC<AdminProps> = ({ onAddProperty }) => {
  const [activeTab, setActiveTab] = useState<'form' | 'leads'>('form');
  const [success, setSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [galleryPreviews, setGalleryPreviews] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const [leads, setLeads] = useState<any[]>([]);
  const [loadingLeads, setLoadingLeads] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [formData, setFormData] = useState<Partial<Property>>({
    code: '',
    title: '',
    description: '',
    type: 'Casa',
    status: 'Venda',
    city: '',
    state: '',
    region: '',
    address: '',
    bedrooms: 0,
    bathrooms: 0,
    parkingSpots: 0,
    area: 0,
    price: 0,
    gallery: [],
    featured: false
  });

  useEffect(() => {
    if (activeTab === 'leads') {
      fetchLeads();
    }
  }, [activeTab]);

  const fetchLeads = async () => {
    setLoadingLeads(true);
    try {
      const data = await propertyService.getInquiries();
      setLeads(data);
    } catch (err) {
      console.error("Erro ao carregar leads:", err);
    } finally {
      setLoadingLeads(false);
    }
  };

  const handleDeleteLead = async (id: string) => {
    if (!window.confirm("Deseja realmente excluir este lead?")) return;
    try {
      await propertyService.deleteInquiry(id);
      setLeads(leads.filter(l => l.id !== id));
    } catch (err) {
      alert("Erro ao excluir lead.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("A imagem deve ter no máximo 5MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImagePreview(base64String);
        setFormData({ ...formData, mainImage: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImagePreview(null);
    setFormData({ ...formData, mainImage: undefined });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length > 0) {
      files.forEach(file => {
        if (file.size > 5 * 1024 * 1024) {
          alert(`A imagem ${file.name} deve ter no máximo 5MB.`);
          return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          setGalleryPreviews(prev => [...prev, base64String]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeGalleryImage = (index: number) => {
    setGalleryPreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    
    if (!formData.code) {
      setErrorMessage("Por favor, insira um código para o imóvel.");
      return;
    }

    if (!formData.mainImage) {
      setErrorMessage("Por favor, selecione uma imagem principal.");
      return;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      setErrorMessage("Erro: Você precisa estar logado como corretor para publicar.");
      return;
    }

    setIsSubmitting(true);
    try {
      await propertyService.create(formData, formData.mainImage!, galleryPreviews);
      setSuccess(true);
      setImagePreview(null);
      setGalleryPreviews([]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      console.error("Erro ao salvar:", err);
      let msg = err.message || "Erro desconhecido";
      
      if (msg.toLowerCase().includes('bucket')) {
        msg = "O bucket 'properties' não foi encontrado no seu Supabase. Vá em Storage > New Bucket > Nomeie como 'properties' e marque como PUBLIC.";
      } else if (msg.toLowerCase().includes('api key') || msg.toLowerCase().includes('jwt')) {
        msg = "A chave de API configurada no arquivo supabaseClient.ts está incorreta ou expirada.";
      } else if (msg.toLowerCase().includes('row-level security') || msg.toLowerCase().includes('policy')) {
        msg = "Erro de Permissão (RLS): Você precisa estar logado como um usuário autenticado no Supabase para cadastrar imóveis. Verifique se você fez login corretamente na área administrativa.";
      } else if (msg.toLowerCase().includes('column') && (msg.toLowerCase().includes('lat') || msg.toLowerCase().includes('lng'))) {
        msg = "Erro de Banco de Dados: As colunas 'lat' e 'lng' não existem na tabela 'properties'. Execute o script SQL fornecido para corrigir.";
      }
      
      setErrorMessage(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="pt-32 pb-24 container mx-auto px-6 text-center">
        <div className="max-w-md mx-auto bg-neutral-50 p-12 border border-neutral-100 shadow-sm">
          <div className="flex justify-center mb-6">
            <CheckCircle2 size={64} className="text-green-500" strokeWidth={1} />
          </div>
          <h2 className="text-3xl font-serif mb-4">Sucesso!</h2>
          <p className="text-gray-500 mb-10">Seu imóvel de alto padrão foi publicado.</p>
          <div className="space-y-4">
            <button onClick={() => setSuccess(false)} className="w-full py-4 bg-black text-white uppercase tracking-widest text-xs font-display font-bold hover:bg-neutral-800 transition-all">Novo Cadastro</button>
            <button onClick={onAddProperty} className="w-full py-4 border border-black text-black uppercase tracking-widest text-xs font-display font-bold hover:bg-black hover:text-white transition-all">Ver Portfólio</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 bg-white min-h-screen">
      <section className="bg-neutral-50 py-16 border-b border-neutral-100">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-end gap-8">
          <div>
            <span className="text-[10px] uppercase tracking-[0.4em] text-gray-400 font-display font-bold block mb-4">Área Administrativa</span>
            <h1 className="text-4xl md:text-6xl font-serif">Gestão de Portfólio</h1>
          </div>
          <div className="flex items-center gap-4 bg-white p-2 border border-neutral-100 rounded-sm">
            <button onClick={() => setActiveTab('form')} className={`flex items-center gap-3 px-8 py-3 text-[10px] font-display font-bold uppercase tracking-widest transition-all ${activeTab === 'form' ? 'bg-black text-white' : 'text-neutral-400 hover:text-black'}`}><PlusCircle size={16} /> Cadastrar</button>
            <button onClick={() => setActiveTab('leads')} className={`flex items-center gap-3 px-8 py-3 text-[10px] font-display font-bold uppercase tracking-widest transition-all ${activeTab === 'leads' ? 'bg-black text-white' : 'text-neutral-400 hover:text-black'}`}><MessageSquare size={16} /> Mensagens ({leads.length})</button>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-6 py-16">
        {errorMessage && (
          <div className="max-w-5xl mx-auto mb-10 p-8 bg-red-50 border-l-4 border-red-500 flex gap-6 items-start text-red-900 animate-in slide-in-from-left duration-500">
            <AlertCircle className="shrink-0 text-red-500" size={24} />
            <div className="flex-1">
              <h4 className="font-black uppercase tracking-widest text-[10px] mb-2">Erro de Configuração Detectado</h4>
              <p className="text-sm leading-relaxed">{errorMessage}</p>
              <div className="mt-4 p-4 bg-white/50 rounded text-[11px] font-mono">
                <p className="mb-2 font-bold">Execute este comando no SQL Editor do Supabase:</p>
                <code className="block bg-black text-white p-3 rounded select-all">
                  INSERT INTO storage.buckets (id, name, "public") <br/>
                  VALUES ('properties', 'properties', true) <br/>
                  ON CONFLICT (id) DO NOTHING;
                </code>
              </div>
            </div>
            <button onClick={() => setErrorMessage(null)} className="p-1 hover:bg-red-100"><X size={18} /></button>
          </div>
        )}

        {activeTab === 'form' ? (
          <form onSubmit={handleSubmit} className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-16">
              <div className="space-y-8">
                <div className="flex items-center gap-4 border-b border-gray-100 pb-5">
                  <LayoutIcon size={18} className="text-neutral-400" />
                  <h3 className="text-2xl font-serif">Informações Básicas</h3>
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Código de Referência</label>
                  <div className="flex gap-4">
                    <input 
                      required 
                      type="text" 
                      className="flex-1 bg-transparent border-b border-neutral-200 p-4 outline-none focus:border-black text-lg font-serif" 
                      placeholder="Ex: PK-1001" 
                      value={formData.code}
                      onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})} 
                    />
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, code: `PK-${Math.floor(1000 + Math.random() * 9000)}`})}
                      className="px-6 py-2 border border-neutral-200 text-[9px] font-display font-bold uppercase tracking-widest hover:border-black transition-all"
                    >
                      Gerar Código
                    </button>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Título do Imóvel</label>
                  <input required type="text" className="bg-transparent border-b border-neutral-200 p-4 outline-none focus:border-black text-xl font-serif" placeholder="Ex: Mansão Suspensa com Vista Mar" onChange={(e) => setFormData({...formData, title: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-10">
                  <div className="flex flex-col gap-3">
                    <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Tipo</label>
                    <select className="bg-white border border-neutral-100 p-4 text-[10px] uppercase font-bold tracking-widest" value={formData.type} onChange={(e) => setFormData({...formData, type: e.target.value as any})}>
                      <option value="Casa">Casa</option>
                      <option value="Apartamento">Apartamento</option>
                      <option value="Cobertura">Cobertura</option>
                      <option value="Mansão">Mansão</option>
                      <option value="Terreno">Terreno</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-3">
                    <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Negociação</label>
                    <select className="bg-white border border-neutral-100 p-4 text-[10px] uppercase font-bold tracking-widest" value={formData.status} onChange={(e) => setFormData({...formData, status: e.target.value as any})}>
                      <option value="Venda">Venda</option>
                      <option value="Aluguel">Aluguel</option>
                    </select>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Descrição Detalhada</label>
                  <textarea required rows={5} className="bg-neutral-50 border border-neutral-100 p-6 text-sm resize-none focus:outline-none focus:border-neutral-300" placeholder="Acabamentos, diferenciais e localização..." onChange={(e) => setFormData({...formData, description: e.target.value})}></textarea>
                </div>
              </div>

              <div className="space-y-8">
                <div className="flex items-center gap-4 border-b border-gray-100 pb-5">
                  <MapPin size={18} className="text-neutral-400" />
                  <h3 className="text-2xl font-serif">Localização</h3>
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-[0.3em] font-display font-bold text-neutral-400">Endereço</label>
                  <input required placeholder="Rua e número" className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, address: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <input required placeholder="Cidade" className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, city: e.target.value})} />
                  <input required placeholder="UF" maxLength={2} className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, state: e.target.value})} />
                </div>
                <input required placeholder="Bairro" className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, region: e.target.value})} />
                <div className="grid grid-cols-2 gap-6">
                  <input type="number" step="any" placeholder="Latitude (ex: -23.5505)" className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, lat: parseFloat(e.target.value)})} />
                  <input type="number" step="any" placeholder="Longitude (ex: -46.6333)" className="bg-white border border-neutral-100 p-4 text-sm" onChange={(e) => setFormData({...formData, lng: parseFloat(e.target.value)})} />
                </div>
              </div>

              <div className="space-y-8">
                <div className="flex items-center gap-4 border-b border-gray-100 pb-5">
                  <Camera size={18} className="text-neutral-400" />
                  <h3 className="text-2xl font-serif">Foto Principal</h3>
                </div>
                {!imagePreview ? (
                  <div onClick={() => fileInputRef.current?.click()} className="cursor-pointer border-2 border-dashed border-neutral-200 h-64 flex flex-col items-center justify-center gap-4 hover:border-black transition-all bg-neutral-50">
                    <Upload size={24} className="text-neutral-300" />
                    <span className="text-[10px] uppercase font-bold tracking-widest text-neutral-400">Upload Imagem (JPG/PNG)</span>
                  </div>
                ) : (
                  <div className="relative h-96 group rounded-sm overflow-hidden shadow-xl">
                    <img src={imagePreview} className="w-full h-full object-cover" alt="Preview" />
                    <button type="button" onClick={removeImage} className="absolute top-4 right-4 bg-white p-3 rounded-full shadow-lg text-red-600 hover:scale-110 transition-transform"><Trash2 size={20} /></button>
                  </div>
                )}
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
              </div>

              <div className="space-y-8">
                <div className="flex items-center gap-4 border-b border-gray-100 pb-5">
                  <ImageIcon size={18} className="text-neutral-400" />
                  <h3 className="text-2xl font-serif">Galeria de Fotos</h3>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {galleryPreviews.map((preview, idx) => (
                    <div key={idx} className="relative aspect-[4/3] group rounded-sm overflow-hidden shadow-md">
                      <img src={preview} className="w-full h-full object-cover" alt={`Gallery ${idx}`} />
                      <button 
                        type="button" 
                        onClick={() => removeGalleryImage(idx)} 
                        className="absolute top-2 right-2 bg-white/90 p-2 rounded-full shadow-sm text-red-600 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                  <div 
                    onClick={() => galleryInputRef.current?.click()} 
                    className="cursor-pointer border-2 border-dashed border-neutral-200 aspect-[4/3] flex flex-col items-center justify-center gap-2 hover:border-black transition-all bg-neutral-50"
                  >
                    <PlusCircle size={20} className="text-neutral-300" />
                    <span className="text-[8px] uppercase font-bold tracking-widest text-neutral-400">Adicionar Foto</span>
                  </div>
                </div>
                <input type="file" ref={galleryInputRef} className="hidden" accept="image/*" multiple onChange={handleGalleryChange} />
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-neutral-50 p-10 border border-neutral-100 sticky top-32 shadow-xl rounded-sm">
                <div className="flex flex-col gap-8">
                  <div className="flex flex-col gap-3">
                    <label className="text-[9px] uppercase tracking-widest font-bold text-neutral-500">Valor (R$)</label>
                    <input required type="number" step="0.01" className="bg-transparent border-b border-neutral-300 py-3 font-serif text-3xl font-bold outline-none focus:border-black" placeholder="1.500.000,00" onChange={(e) => setFormData({...formData, price: Number(e.target.value)})} />
                    {formData.price && formData.price > 0 && (
                      <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest mt-1">
                        Visualização: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 }).format(formData.price)}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-6">
                     <div className="flex flex-col gap-3">
                        <label className="text-[9px] uppercase tracking-widest font-bold text-neutral-500">Área (m²)</label>
                        <input required placeholder="0" type="number" className="bg-white border border-neutral-100 p-4 text-sm font-bold" onChange={(e) => setFormData({...formData, area: Number(e.target.value)})} />
                     </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="flex flex-col gap-3">
                          <label className="text-[9px] uppercase tracking-widest font-bold text-neutral-500">Quartos</label>
                          <input placeholder="0" type="number" className="bg-white border border-neutral-100 p-4 text-sm font-bold" onChange={(e) => setFormData({...formData, bedrooms: Number(e.target.value)})} />
                        </div>
                        <div className="flex flex-col gap-3">
                          <label className="text-[9px] uppercase tracking-widest font-bold text-neutral-500">Suítes/Banh</label>
                          <input placeholder="0" type="number" className="bg-white border border-neutral-100 p-4 text-sm font-bold" onChange={(e) => setFormData({...formData, bathrooms: Number(e.target.value)})} />
                        </div>
                     </div>
                  </div>

                  <div className="flex items-center gap-4 py-4 border-y border-neutral-200">
                    <input type="checkbox" id="featured" className="w-5 h-5 accent-black" onChange={(e) => setFormData({...formData, featured: e.target.checked})} />
                    <label htmlFor="featured" className="text-[10px] uppercase font-bold tracking-widest cursor-pointer">Destacar na Home</label>
                  </div>

                  <button 
                    type="submit" 
                    disabled={isSubmitting} 
                    className="w-full py-6 bg-black text-white uppercase tracking-widest text-[10px] font-bold hover:bg-neutral-800 disabled:bg-neutral-400 transition-all shadow-xl flex items-center justify-center gap-4"
                  >
                    {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : 'Publicar Agora'}
                  </button>
                </div>
              </div>
            </div>
          </form>
        ) : (
          <div className="max-w-6xl mx-auto space-y-6">
            {loadingLeads ? (
              <div className="py-32 flex justify-center"><Loader2 className="animate-spin text-neutral-200" size={32} /></div>
            ) : leads.length > 0 ? (
              leads.map((lead) => (
                <div key={lead.id} className="bg-white border border-neutral-100 p-10 flex flex-col md:flex-row gap-12 group hover:shadow-2xl transition-all">
                  <div className="md:w-1/3 space-y-4">
                    <div className="text-xs font-bold uppercase tracking-widest flex items-center gap-3"><User size={14} className="text-neutral-300" /> {lead.name}</div>
                    <div className="text-xs text-neutral-500 flex items-center gap-3"><Mail size={14} className="text-neutral-300" /> {lead.email}</div>
                  </div>
                  <div className="flex-grow space-y-4 border-l border-neutral-100 pl-12">
                    <p className="text-neutral-600 italic">"{lead.message}"</p>
                    <span className="text-[9px] uppercase tracking-widest text-neutral-300 font-bold">Data: {new Date(lead.created_at).toLocaleDateString()}</span>
                  </div>
                  <div className="md:w-1/6 flex flex-col justify-center gap-4">
                    <button onClick={() => handleDeleteLead(lead.id)} className="text-red-500 text-[9px] uppercase font-bold hover:underline flex items-center gap-2"><Trash2 size={12} /> Excluir</button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-48 bg-neutral-50 border border-dashed border-neutral-200">
                <p className="text-[10px] uppercase font-bold tracking-widest text-neutral-400">Nenhum lead encontrado.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
