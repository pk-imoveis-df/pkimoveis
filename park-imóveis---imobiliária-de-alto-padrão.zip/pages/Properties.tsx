
import React, { useState, useMemo } from 'react';
import { Property, SearchFilters } from '../types';
import PropertyCard from '../components/PropertyCard';
import { Search, SlidersHorizontal, Grid, List as ListIcon, X, ChevronDown } from 'lucide-react';

interface PropertiesProps {
  properties: Property[];
  onSelectProperty: (id: string) => void;
  onNavigate: (page: string) => void;
  initialFilters?: SearchFilters;
}

const Properties: React.FC<PropertiesProps> = ({ properties, onSelectProperty, onNavigate, initialFilters }) => {
  const [filters, setFilters] = useState<SearchFilters>(initialFilters || {
    type: '',
    minPrice: 0,
    maxPrice: 0,
    location: '',
    city: '',
    state: '',
    bedrooms: 0,
    bathrooms: 0,
    parkingSpots: 0
  });
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const filteredProperties = useMemo(() => {
    return properties.filter(p => {
      const matchType = !filters.type || p.type === filters.type;
      const matchMaxPrice = !filters.maxPrice || p.price <= filters.maxPrice;
      const matchMinPrice = !filters.minPrice || p.price >= filters.minPrice;
      const matchBedrooms = !filters.bedrooms || p.bedrooms >= filters.bedrooms;
      const matchBathrooms = !filters.bathrooms || p.bathrooms >= filters.bathrooms;
      const matchParking = !filters.parkingSpots || p.parkingSpots >= filters.parkingSpots;
      
      const matchSearch = !searchTerm || 
        p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.code.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchLocation = !filters.location || 
        p.city.toLowerCase().includes(filters.location.toLowerCase()) ||
        p.state.toLowerCase().includes(filters.location.toLowerCase());

      return matchType && matchMaxPrice && matchMinPrice && matchBedrooms && matchBathrooms && matchParking && matchSearch && matchLocation;
    });
  }, [properties, filters, searchTerm]);

  return (
    <div className="pt-24 min-h-screen bg-white">
      {/* Header Info - Clean & Sophisticated */}
      <div className="bg-neutral-50 py-28 border-b border-neutral-100">
        <div className="container mx-auto px-6">
          <span className="text-[10px] uppercase tracking-[0.5em] text-gray-400 font-display font-bold block mb-5">Curadoria Exclusiva</span>
          <h1 className="text-5xl md:text-8xl font-serif mb-8 leading-none tracking-tight">Portfólio de<br/>Propriedades</h1>
          <p className="text-gray-500 max-w-xl text-lg leading-relaxed font-light">
            Uma seleção rigorosa de imóveis que definem o novo padrão de moradia de luxo no Brasil.
          </p>
        </div>
      </div>

      {/* Toolbar & Filters - Premium Sticky Header */}
      <div className="sticky top-[72px] md:top-[80px] z-40 bg-white border-b border-neutral-100 py-6">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Minimalist Search */}
          <div className="relative w-full md:w-2/5 group">
            <Search className="absolute left-0 top-1/2 -translate-y-1/2 text-neutral-300 group-focus-within:text-black transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="BUSCAR POR NOME OU REGIÃO..."
              className="w-full pl-8 pr-6 py-3 bg-transparent border-b border-neutral-100 focus:border-black outline-none text-[10px] font-display font-bold uppercase tracking-[0.25em] transition-all placeholder:text-neutral-300"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-6 w-full md:w-auto">
            {/* High-End Filter Toggle Button - Refined to match Header Action */}
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`group flex items-center justify-center gap-4 px-10 py-3.5 text-[10px] font-display font-bold uppercase tracking-[0.3em] transition-all border rounded-sm min-w-[200px] ${
                showFilters 
                  ? 'bg-black text-white border-black shadow-lg' 
                  : 'bg-white text-black border-neutral-200 hover:border-black'
              }`}
            >
              <SlidersHorizontal size={14} className={showFilters ? 'rotate-90 transition-transform' : 'transition-transform'} />
              {showFilters ? 'OCULTAR FILTROS' : 'REFINAR BUSCA'}
            </button>

            {/* View Mode Toggle - Refined */}
            <div className="hidden lg:flex items-center gap-1 border border-neutral-100 p-1 rounded-sm">
              <button className="p-3 bg-neutral-950 text-white rounded-sm transition-all"><Grid size={16}/></button>
              <button className="p-3 text-neutral-300 hover:text-black transition-colors"><ListIcon size={16}/></button>
            </div>
          </div>
        </div>

        {/* Premium Expanded Filter Panel */}
        <div className={`overflow-hidden transition-all duration-500 ease-in-out bg-neutral-50/80 backdrop-blur-md ${showFilters ? 'max-h-[800px] border-b border-neutral-100 opacity-100 shadow-inner' : 'max-h-0 opacity-0'}`}>
          <div className="container mx-auto px-6 py-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-8">
              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Categoria</label>
                <div className="relative group">
                  <select 
                    className="w-full bg-white border border-neutral-100 p-4 appearance-none outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all cursor-pointer shadow-sm hover:border-neutral-300"
                    value={filters.type}
                    onChange={(e) => setFilters({...filters, type: e.target.value})}
                  >
                    <option value="">Todas as Opções</option>
                    <option value="Casa">Casas Luxo</option>
                    <option value="Apartamento">Apartamentos Prime</option>
                    <option value="Cobertura">Penthouses</option>
                    <option value="Mansão">Mansões Elite</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-300" />
                </div>
              </div>
              
              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Valor Mínimo</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[9px] font-display font-bold text-neutral-300">BRL</span>
                  <input 
                    type="number" 
                    placeholder="0"
                    className="w-full bg-white border border-neutral-100 p-4 pl-14 outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all shadow-sm hover:border-neutral-300"
                    value={filters.minPrice || ''}
                    onChange={(e) => setFilters({...filters, minPrice: Number(e.target.value)})}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Valor Máximo</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[9px] font-display font-bold text-neutral-300">BRL</span>
                  <input 
                    type="number" 
                    placeholder="ILIMITADO"
                    className="w-full bg-white border border-neutral-100 p-4 pl-14 outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all shadow-sm hover:border-neutral-300"
                    value={filters.maxPrice || ''}
                    onChange={(e) => setFilters({...filters, maxPrice: Number(e.target.value)})}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Quartos</label>
                <div className="relative group">
                  <select 
                    className="w-full bg-white border border-neutral-100 p-4 appearance-none outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all cursor-pointer shadow-sm hover:border-neutral-300"
                    value={filters.bedrooms || 0}
                    onChange={(e) => setFilters({...filters, bedrooms: Number(e.target.value)})}
                  >
                    <option value="0">Qualquer</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                    <option value="5">5+</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-300" />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Banheiros</label>
                <div className="relative group">
                  <select 
                    className="w-full bg-white border border-neutral-100 p-4 appearance-none outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all cursor-pointer shadow-sm hover:border-neutral-300"
                    value={filters.bathrooms || 0}
                    onChange={(e) => setFilters({...filters, bathrooms: Number(e.target.value)})}
                  >
                    <option value="0">Qualquer</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                    <option value="5">5+</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-300" />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Vagas</label>
                <div className="relative group">
                  <select 
                    className="w-full bg-white border border-neutral-100 p-4 appearance-none outline-none focus:border-black text-[10px] font-display font-bold uppercase tracking-[0.2em] transition-all cursor-pointer shadow-sm hover:border-neutral-300"
                    value={filters.parkingSpots || 0}
                    onChange={(e) => setFilters({...filters, parkingSpots: Number(e.target.value)})}
                  >
                    <option value="0">Qualquer</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                    <option value="5">5+</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-300" />
                </div>
              </div>
            </div>

            <div className="mt-12 flex justify-end">
              <button 
                onClick={() => setFilters({ type: '', minPrice: 0, maxPrice: 0, location: '', city: '', state: '', bedrooms: 0, bathrooms: 0, parkingSpots: 0 })}
                className="flex items-center gap-3 text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400 hover:text-black transition-all group pb-1 border-b border-transparent hover:border-neutral-400"
              >
                <X size={12} className="group-hover:rotate-90 transition-transform" />
                REDEFINIR FILTROS
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="container mx-auto px-6 py-24">
        <div className="flex flex-col md:flex-row justify-between items-center mb-16 border-b border-neutral-100 pb-10 gap-6">
          <p className="text-[10px] uppercase tracking-[0.5em] text-neutral-400 font-display font-bold">
            EXIBINDO <span className="text-black">{filteredProperties.length} PROPRIEDADES</span> ENCONTRADAS
          </p>
          <div className="flex items-center gap-6">
            <span className="text-[10px] uppercase tracking-[0.5em] text-neutral-200 font-display font-bold">ORDEM:</span>
            <select className="bg-transparent text-[10px] font-display font-bold uppercase tracking-[0.3em] outline-none cursor-pointer hover:text-gray-500 transition-colors">
              <option>PADRÃO</option>
              <option>VALOR CRESCENTE</option>
              <option>VALOR DECRESCENTE</option>
              <option>ÁREA TOTAL</option>
            </select>
          </div>
        </div>

        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-x-8 gap-y-16">
            {filteredProperties.map((p) => (
              <PropertyCard 
                key={p.id} 
                property={p} 
                onClick={onSelectProperty} 
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-48 border border-dashed border-neutral-200 bg-neutral-50/30 rounded-sm">
            <div className="mb-10 flex justify-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-sm border border-neutral-100">
                <Search size={32} className="text-neutral-100" strokeWidth={1} />
              </div>
            </div>
            <h3 className="text-3xl font-serif mb-4">Nenhum resultado</h3>
            <p className="text-neutral-400 font-display text-[10px] uppercase tracking-[0.4em] max-w-sm mx-auto leading-loose">
              Tente remover alguns filtros ou buscar por termos mais genéricos para encontrar seu imóvel.
            </p>
            <button 
              onClick={() => {
                setFilters({ type: '', minPrice: 0, maxPrice: 0, location: '', city: '', state: '', bedrooms: 0, bathrooms: 0, parkingSpots: 0 });
                setSearchTerm('');
              }}
              className="mt-12 px-12 py-5 bg-black text-white text-[10px] font-display font-bold uppercase tracking-[0.4em] hover:bg-neutral-800 transition-all shadow-xl rounded-sm"
            >
              LIMPAR TUDO
            </button>
          </div>
        )}
      </div>

      {/* Luxury CTA - Refined */}
      <section className="bg-neutral-950 py-40">
        <div className="container mx-auto px-6 text-center">
          <span className="text-[10px] uppercase tracking-[0.6em] text-neutral-500 font-display font-bold block mb-8">Personal Shopper</span>
          <h2 className="text-white text-4xl md:text-6xl font-serif mb-12 max-w-4xl mx-auto leading-[1.1]">
            Não encontrou o que procurava em nosso catálogo?
          </h2>
          <p className="text-neutral-500 font-display text-[11px] uppercase tracking-[0.4em] mb-16">Nós buscamos o imóvel ideal para você no mercado off-market.</p>
          <button 
            onClick={() => onNavigate('contact')}
            className="px-16 py-6 bg-white text-black text-[10px] font-display font-medium uppercase tracking-[0.2em] hover:bg-neutral-100 transition-all rounded-sm shadow-2xl transform hover:-translate-y-1 duration-500"
          >
            Falar com Consultor Senior
          </button>
        </div>
      </section>
    </div>
  );
};

export default Properties;
