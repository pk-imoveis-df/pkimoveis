
import React, { useEffect, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Instagram, Linkedin, MessageSquare, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { propertyService } from '../services/propertyService';

interface ContactProps {
  initialAddress?: string | null;
}

const Contact: React.FC<ContactProps> = ({ initialAddress }) => {
  const mapSectionRef = useRef<HTMLElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Gostaria de Comprar',
    message: ''
  });

  const [errors, setErrors] = useState<Partial<Record<keyof typeof formData, string>>>({});

  useEffect(() => {
    if (initialAddress && mapSectionRef.current) {
      mapSectionRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [initialAddress]);

  const validateField = (name: string, value: string) => {
    let error = '';
    if (name === 'name') {
      if (!value.trim()) error = 'O nome é obrigatório.';
      else if (value.trim().length < 3) error = 'O nome deve ter pelo menos 3 caracteres.';
    } else if (name === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!value.trim()) error = 'O e-mail é obrigatório.';
      else if (!emailRegex.test(value)) error = 'Por favor, insira um e-mail válido.';
    } else if (name === 'message') {
      if (!value.trim()) error = 'A mensagem não pode estar vazia.';
      else if (value.trim().length < 10) error = 'A mensagem deve conter pelo menos 10 caracteres.';
    }
    return error;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Validação em tempo real
    const error = validateField(name, value);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validar todos os campos antes de enviar
    const newErrors: Partial<Record<keyof typeof formData, string>> = {};
    Object.keys(formData).forEach(key => {
      const error = validateField(key, formData[key as keyof typeof formData]);
      if (error) newErrors[key as keyof typeof formData] = error;
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);
    try {
      // Envia como um lead geral (sem propertyId)
      await propertyService.submitInquiry({
        name: formData.name,
        email: formData.email,
        phone: '', // Opcional no contato geral
        message: `[ASSUNTO: ${formData.subject}] ${formData.message}`
      });
      
      setIsSuccess(true);
      setFormData({ name: '', email: '', subject: 'Gostaria de Comprar', message: '' });
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (err) {
      console.error("Erro ao enviar contato:", err);
      alert("Houve um erro ao processar sua solicitação. Tente novamente em alguns instantes.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Endereço padrão de Brasília para o mapa
  const addressForMap = initialAddress || "Águas Claras Shopping, Brasília - DF";
  const publicMapUrl = `https://maps.google.com/maps?q=${encodeURIComponent(addressForMap)}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

  return (
    <div className="pt-24 bg-white min-h-screen">
      <section className="py-24 container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          <div>
            <span className="text-[10px] uppercase tracking-[0.3em] text-gray-400 font-bold block mb-4">Contato</span>
            <h1 className="text-5xl font-serif mb-12">Vamos Conversar Sobre Seu Futuro Endereço.</h1>
            
            <div className="space-y-10">
              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-neutral-100 flex items-center justify-center shrink-0">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="font-bold uppercase tracking-widest text-[10px] text-gray-400 mb-2">Ligue para nós</h4>
                  <p className="text-xl">+55 (61) 99658-7308</p>
                  <p className="text-gray-500 text-sm mt-1">Segunda a Sexta, das 9h às 19h.</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-neutral-100 flex items-center justify-center shrink-0">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-bold uppercase tracking-widest text-[10px] text-gray-400 mb-2">E-mail</h4>
                  <p className="text-xl">contato@parkimoveis.com.br</p>
                  <p className="text-gray-500 text-sm mt-1">Respondemos em até 2 horas.</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-neutral-100 flex items-center justify-center shrink-0">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="font-bold uppercase tracking-widest text-[10px] text-gray-400 mb-2">Sede Social</h4>
                  <p className="text-xl">Águas Claras Shopping, Salas 306 e 307</p>
                  <p className="text-gray-500 text-sm mt-1">Águas Claras, Brasília - DF.</p>
                </div>
              </div>
            </div>

            <div className="mt-20 pt-10 border-t border-gray-100 flex gap-8">
              <a href="https://www.instagram.com/parkimoveisbrasilia/#" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:text-gray-500 transition-colors">
                <span className="w-5 h-5 flex items-center justify-center"><Instagram size={18} /></span> Instagram
              </a>
              <a href="https://www.linkedin.com/company/park-imoveis-brasilia/?viewAsMember=true" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:text-gray-500 transition-colors">
                <span className="w-5 h-5 flex items-center justify-center"><Linkedin size={18} /></span> Linkedin
              </a>
              <a href="https://wa.me/5561996587308" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest hover:text-gray-500 transition-colors text-green-600">
                <span className="w-5 h-5 flex items-center justify-center"><MessageSquare size={18} /></span> WhatsApp
              </a>
            </div>
          </div>

          <div className="bg-neutral-50 p-12 lg:p-16 shadow-sm border border-neutral-100 relative overflow-hidden">
            {isSuccess && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center text-center p-12 animate-in fade-in duration-500">
                <CheckCircle size={64} className="text-green-500 mb-6" strokeWidth={1} />
                <h3 className="text-3xl font-serif mb-4">Mensagem Enviada</h3>
                <p className="text-neutral-400 text-[10px] uppercase tracking-[0.4em] font-display font-bold leading-loose">
                  Obrigado pelo contato. Um de nossos especialistas retornará sua mensagem em breve.
                </p>
                <button 
                  onClick={() => setIsSuccess(false)}
                  className="mt-10 text-[10px] uppercase tracking-widest font-display font-bold border-b border-black pb-1 hover:text-neutral-500 hover:border-neutral-500 transition-all"
                >
                  Enviar nova mensagem
                </button>
              </div>
            )}

            <h3 className="text-2xl font-serif mb-10">Envie uma Mensagem</h3>
            <form className="space-y-8" onSubmit={handleSubmit} noValidate>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500">Nome</label>
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`bg-white border-b p-4 outline-none transition-all ${errors.name ? 'border-red-500 focus:border-red-600' : 'border-gray-200 focus:border-black'}`} 
                    placeholder="Seu nome completo"
                  />
                  {errors.name && (
                    <span className="text-[9px] text-red-500 font-bold uppercase tracking-tighter flex items-center gap-1">
                      <AlertCircle size={10} /> {errors.name}
                    </span>
                  )}
                </div>
                <div className="flex flex-col gap-3">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500">E-mail</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`bg-white border-b p-4 outline-none transition-all ${errors.email ? 'border-red-500 focus:border-red-600' : 'border-gray-200 focus:border-black'}`} 
                    placeholder="seu@email.com"
                  />
                  {errors.email && (
                    <span className="text-[9px] text-red-500 font-bold uppercase tracking-tighter flex items-center gap-1">
                      <AlertCircle size={10} /> {errors.email}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500">Assunto</label>
                <select 
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="bg-white border-b border-gray-200 p-4 outline-none focus:border-black transition-all text-sm font-display font-medium"
                >
                  <option>Gostaria de Comprar</option>
                  <option>Gostaria de Vender meu Imóvel</option>
                  <option>Solicitar Avaliação</option>
                  <option>Outros Assuntos</option>
                </select>
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-[10px] uppercase tracking-widest font-bold text-gray-500">Mensagem</label>
                <textarea 
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={5} 
                  className={`bg-white border-b p-4 outline-none transition-all resize-none ${errors.message ? 'border-red-500 focus:border-red-600' : 'border-gray-200 focus:border-black'}`}
                  placeholder="Como podemos ajudar?"
                ></textarea>
                {errors.message && (
                  <span className="text-[9px] text-red-500 font-bold uppercase tracking-tighter flex items-center gap-1">
                    <AlertCircle size={10} /> {errors.message}
                  </span>
                )}
              </div>
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full py-6 bg-black text-white uppercase tracking-[0.4em] text-[10px] font-display font-bold hover:bg-neutral-800 transition-all flex items-center justify-center gap-3 disabled:bg-neutral-400 shadow-xl"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={16} className="animate-spin" /> Processando...
                  </>
                ) : 'Enviar Solicitação'}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Map Section - Focused on Address */}
      <section ref={mapSectionRef} className="h-[600px] w-full bg-neutral-200 relative">
        <div className="absolute top-6 left-6 z-10 bg-white p-4 shadow-xl border border-neutral-100 max-w-xs rounded-sm">
          <h4 className="text-xs uppercase tracking-widest font-bold mb-2">Localização no Mapa</h4>
          <p className="text-sm text-gray-500">{addressForMap}</p>
        </div>
        <iframe 
          src={publicMapUrl} 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen={true} 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </div>
  );
};

export default Contact;
