
import React, { useState, useEffect } from 'react';
import { Property } from '../types';
import SEO from '../components/SEO';
import { MapPin, Maximize, BedDouble, Bath, Car, Share2, Heart, ChevronLeft, ChevronRight, Map as MapIcon, Loader2, CheckCircle } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { optimizeUnsplashUrl } from '../services/imageService';
import { supabase } from '../supabaseClient';
import { propertyService } from '../services/propertyService';

// Fix Leaflet marker icon issue
const DefaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface PropertyDetailProps {
  property: Property;
  onBack: () => void;
  onViewLocation: (address: string) => void;
}

const PropertyDetail: React.FC<PropertyDetailProps> = ({ property, onBack, onViewLocation }) => {
  const [currentImage, setCurrentImage] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [inquiryData, setInquiryData] = useState({
    name: '',
    email: '',
    phone: '',
    message: `Olá, gostaria de receber mais detalhes sobre a propriedade "${property.title}".`
  });

  const gallery = [property.mainImage, ...(property.gallery || [])];

  useEffect(() => {
    const nextIndex = (currentImage + 1) % gallery.length;
    const img = new Image();
    img.src = gallery[nextIndex];
  }, [currentImage, gallery]);

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) {
      alert("Serviço indisponível no momento.");
      return;
    }

    setIsSubmitting(true);
    try {
      await propertyService.submitInquiry({
        name: inquiryData.name,
        email: inquiryData.email,
        phone: inquiryData.phone,
        message: inquiryData.message,
        propertyId: property.id
      });

      setIsSuccess(true);
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (err) {
      console.error("Erro ao enviar solicitação:", err);
      alert("Ocorreu um erro ao enviar sua mensagem. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const formattedPrice = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(property.price);

  return (
    <div className="pt-24 bg-white min-h-screen">
      <SEO 
        title={property.title} 
        description={`${property.type} em ${property.region}, ${property.city}. ${property.bedrooms} quartos, ${property.area}m². ${property.description.substring(0, 100)}...`}
        ogImage={property.mainImage}
        canonical={`/imovel/${property.id}`}
      />
      {/* Navigation & Actions */}
      <div className="container mx-auto px-6 py-8 flex justify-between items-center">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 text-[10px] uppercase tracking-[0.4em] font-display font-bold hover:text-neutral-400 transition-all group"
        >
          <ChevronLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          Voltar ao Catálogo
        </button>
        <div className="flex gap-5">
          <button className="p-4 border border-neutral-100 hover:bg-neutral-50 transition-all rounded-full shadow-sm" title="Compartilhar"><Share2 size={16} /></button>
          <button className="p-4 border border-neutral-100 hover:bg-neutral-50 transition-all rounded-full shadow-sm" title="Favoritar"><Heart size={16} /></button>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="container mx-auto px-6 mb-20">
        <div className="relative aspect-[21/9] bg-neutral-100 overflow-hidden group rounded-sm shadow-2xl">
          <img 
            src={gallery[currentImage]} 
            alt={`${property.title}`}
            className="w-full h-full object-cover transition-all duration-1000 ease-out group-hover:scale-105"
            decoding="async"
            style={{ fetchPriority: 'high' } as any}
          />
          
          {gallery.length > 1 && (
            <>
              <button 
                onClick={() => setCurrentImage((prev) => (prev - 1 + gallery.length) % gallery.length)}
                className="absolute left-10 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/95 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-black hover:text-white shadow-xl"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={() => setCurrentImage((prev) => (prev + 1) % gallery.length)}
                className="absolute right-10 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/95 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-black hover:text-white shadow-xl"
              >
                <ChevronRight size={20} />
              </button>
            </>
          )}
          
          <div className="absolute bottom-10 right-10 bg-black/80 backdrop-blur-sm text-white px-6 py-3 text-[10px] tracking-[0.3em] font-display font-bold rounded-sm">
            {currentImage + 1} &nbsp; / &nbsp; {gallery.length}
          </div>
        </div>
        
        {gallery.length > 1 && (
          <div className="flex gap-4 mt-6 overflow-x-auto pb-6 custom-scrollbar">
            {gallery.map((img, idx) => (
              <button 
                key={idx}
                onClick={() => setCurrentImage(idx)}
                className={`flex-shrink-0 w-44 aspect-[3/2] overflow-hidden border transition-all duration-500 rounded-sm ${
                  currentImage === idx ? 'border-black opacity-100 scale-105 shadow-xl' : 'border-neutral-100 opacity-40 hover:opacity-70'
                }`}
              >
            <img 
              key={idx}
              src={optimizeUnsplashUrl(img, 200)} 
              alt={`Thumb ${idx + 1}`} 
              className="w-full h-full object-cover" 
              loading="lazy" 
            />
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-24 pb-32">
        {/* Main Info */}
        <div className="lg:col-span-2">
          <div className="mb-14">
            <span className="text-[10px] text-neutral-400 uppercase tracking-[0.5em] font-display font-bold block mb-6">
              Cód: {property.code} &nbsp; • &nbsp; {property.type} &nbsp; • &nbsp; {property.status}
            </span>
            <h1 className="text-5xl md:text-7xl font-serif mb-8 leading-none tracking-tight">{property.title}</h1>
            <div className="flex items-center gap-3 text-neutral-500 text-xl border-l-2 border-neutral-100 pl-6 py-2">
              <MapPin size={22} strokeWidth={1.5} className="text-neutral-300" />
              <span className="font-light">{property.address} — {property.region}, {property.city}</span>
            </div>
            <button 
              onClick={() => onViewLocation(`${property.address}, ${property.region}, ${property.city}`)}
              className="mt-12 flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] font-display font-bold border border-neutral-200 px-10 py-5 hover:bg-black hover:text-white transition-all transform hover:-translate-y-1"
            >
              <MapIcon size={16} />
              Localização Privilegiada
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 py-12 border-y border-neutral-100 mb-16">
            <div className="space-y-3">
              <span className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-300">Área Privativa</span>
              <div className="flex items-center gap-4">
                <Maximize size={24} strokeWidth={1} className="text-black" />
                <span className="text-2xl font-serif">{property.area} m²</span>
              </div>
            </div>
            <div className="space-y-3">
              <span className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-300">Suítes</span>
              <div className="flex items-center gap-4">
                <BedDouble size={24} strokeWidth={1} className="text-black" />
                <span className="text-2xl font-serif">{property.bedrooms}</span>
              </div>
            </div>
            <div className="space-y-3">
              <span className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-300">Banheiros</span>
              <div className="flex items-center gap-4">
                <Bath size={24} strokeWidth={1} className="text-black" />
                <span className="text-2xl font-serif">{property.bathrooms}</span>
              </div>
            </div>
            <div className="space-y-3">
              <span className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-300">Vagas</span>
              <div className="flex items-center gap-4">
                <Car size={24} strokeWidth={1} className="text-black" />
                <span className="text-2xl font-serif">{property.parkingSpots}</span>
              </div>
            </div>
          </div>

          <div className="prose prose-2xl max-w-none text-neutral-500 leading-relaxed font-light">
            <h3 className="text-3xl font-serif text-black mb-10 tracking-tight">O Projeto</h3>
            <p className="mb-8">{property.description}</p>
            <p className="mb-16">
              Projetado para quem valoriza a exclusividade e o bem-estar, este imóvel integra perfeitamente design contemporâneo com funcionalidade. A iluminação natural é um dos pilares deste projeto, criando ambientes arejados e convidativos em qualquer época do ano.
            </p>

            {/* Interactive Map Section */}
            <div className="mb-16">
              <h3 className="text-3xl font-serif text-black mb-10 tracking-tight">Localização</h3>
              <div className="h-[500px] w-full bg-neutral-100 rounded-sm overflow-hidden shadow-inner border border-neutral-100 relative z-10">
                {property.lat && property.lng ? (
                  <MapContainer 
                    center={[property.lat, property.lng]} 
                    zoom={15} 
                    scrollWheelZoom={false}
                    className="h-full w-full"
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <Marker position={[property.lat, property.lng]}>
                      <Popup>
                        <div className="p-2">
                          <h4 className="font-bold text-sm mb-1">{property.title}</h4>
                          <p className="text-xs text-neutral-500">{property.address}</p>
                        </div>
                      </Popup>
                    </Marker>
                  </MapContainer>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-neutral-400 gap-4">
                    <MapPin size={48} strokeWidth={1} />
                    <p className="text-[10px] uppercase tracking-[0.4em] font-display font-bold">Coordenadas não disponíveis</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Form */}
        <div>
          <div className="sticky top-32 bg-neutral-50 p-12 shadow-2xl border border-neutral-100 rounded-sm overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-black"></div>
            <div className="mb-12">
              <span className="text-[9px] uppercase tracking-[0.5em] text-neutral-400 font-display font-bold block mb-3">Valor Estimado</span>
              <div className="text-5xl font-serif font-bold text-black tracking-tighter">{formattedPrice}</div>
            </div>

            {isSuccess ? (
              <div className="py-12 text-center space-y-6 animate-in fade-in zoom-in duration-500">
                <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle size={40} />
                </div>
                <h4 className="text-2xl font-serif">Solicitação Enviada!</h4>
                <p className="text-neutral-400 text-xs font-display font-bold uppercase tracking-widest leading-loose">
                  Nossos consultores entrarão em contato em até 24 horas.
                </p>
              </div>
            ) : (
              <form className="space-y-8" onSubmit={handleInquirySubmit}>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Nome Completo</label>
                  <input 
                    required 
                    type="text" 
                    className="w-full bg-white border border-neutral-100 p-4 outline-none focus:border-black transition-all text-sm font-display font-medium" 
                    placeholder="Seu nome"
                    value={inquiryData.name}
                    onChange={(e) => setInquiryData({...inquiryData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">E-mail Corporativo</label>
                  <input 
                    required 
                    type="email" 
                    className="w-full bg-white border border-neutral-100 p-4 outline-none focus:border-black transition-all text-sm font-display font-medium" 
                    placeholder="seu@email.com"
                    value={inquiryData.email}
                    onChange={(e) => setInquiryData({...inquiryData, email: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Telefone / WhatsApp</label>
                  <input 
                    required 
                    type="tel" 
                    className="w-full bg-white border border-neutral-100 p-4 outline-none focus:border-black transition-all text-sm font-display font-medium" 
                    placeholder="(00) 00000-0000"
                    value={inquiryData.phone}
                    onChange={(e) => setInquiryData({...inquiryData, phone: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] uppercase tracking-[0.4em] font-display font-bold text-neutral-400">Mensagem</label>
                  <textarea 
                    rows={4} 
                    className="w-full bg-white border border-neutral-100 p-4 outline-none focus:border-black transition-all text-sm font-display font-medium resize-none"
                    value={inquiryData.message}
                    onChange={(e) => setInquiryData({...inquiryData, message: e.target.value})}
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-6 bg-black text-white uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-neutral-800 transition-all shadow-xl rounded-sm flex items-center justify-center gap-4"
                >
                  {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : 'Solicitar Orçamento'}
                </button>
                <button type="button" className="w-full py-5 border border-black text-black uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-black hover:text-white transition-all">
                  Agendar Visita VIP
                </button>
              </form>
            )}
            
            <p className="text-[8px] text-neutral-400 mt-10 text-center leading-loose font-display uppercase tracking-widest">
              Sua privacidade é inegociável. Ao enviar, você aceita nossos <span className="underline cursor-pointer">termos de sigilo</span>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
