
import React from 'react';
import { Home, Search, Shield, BarChart3, Users, Key } from 'lucide-react';
import SEO from '../components/SEO';
import { optimizeUnsplashUrl } from '../services/imageService';

interface ServicesProps {
  onNavigate: (page: string) => void;
}

const Services: React.FC<ServicesProps> = ({ onNavigate }) => {
  const serviceList = [
    {
      icon: <Search size={40} strokeWidth={1} />,
      title: 'Consultoria na Compra',
      desc: 'Busca personalizada de imóveis que atendam aos seus critérios mais exigentes, com análise técnica e jurídica completa.'
    },
    {
      icon: <Home size={40} strokeWidth={1} />,
      title: 'Gestão de Vendas',
      desc: 'Estratégia de marketing de alto impacto para vender seu imóvel pelo melhor valor, alcançando o público-alvo ideal.'
    },
    {
      icon: <BarChart3 size={40} strokeWidth={1} />,
      title: 'Avaliação Patrimonial',
      desc: 'Estudos detalhados de mercado para determinar o valor real e potencial de valorização do seu patrimônio imobiliário.'
    },
    {
      icon: <Users size={40} strokeWidth={1} />,
      title: 'Concierge Imobiliário',
      desc: 'Acompanhamento total: da documentação inicial à reforma ou decoração, conectando você aos melhores profissionais.'
    },
    {
      icon: <Shield size={40} strokeWidth={1} />,
      title: 'Assessoria Jurídica',
      desc: 'Segurança absoluta em todas as etapas da transação, com suporte especializado em direito imobiliário de luxo.'
    },
    {
      icon: <Key size={40} strokeWidth={1} />,
      title: 'Investimentos',
      desc: 'Identificação de oportunidades exclusivas em lançamentos e off-market com alto potencial de rentabilidade.'
    }
  ];

  return (
    <div className="pt-24 bg-white min-h-screen">
      <SEO 
        title="Serviços" 
        description="Descubra os serviços exclusivos da Park Imóveis: consultoria na compra, gestão de patrimônio, avaliação técnica e assessoria jurídica para imóveis de luxo."
        canonical="/servicos"
      />
      <section className="bg-neutral-950 py-32 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-20">
          <img src="https://images.unsplash.com/photo-1600607687940-c52af0941981?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <span className="text-[10px] uppercase tracking-[0.3em] text-gray-400 font-bold block mb-4">Soluções Premium</span>
          <h1 className="text-5xl md:text-7xl font-serif max-w-3xl leading-tight">Serviços que Redefinem a Experiência Imobiliária.</h1>
        </div>
      </section>

      <section className="py-32 container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          {serviceList.map((service, idx) => (
            <div key={idx} className="group">
              <div className="mb-8 text-black group-hover:scale-110 transition-transform origin-left">
                {service.icon}
              </div>
              <h3 className="text-2xl font-serif mb-4">{service.title}</h3>
              <p className="text-gray-500 leading-relaxed">
                {service.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-neutral-50 py-32">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center gap-20">
          <div className="flex-1">
            <img 
              src={optimizeUnsplashUrl("https://images.unsplash.com/photo-1577415124269-fc1140a69e91", 1200)} 
              className="w-full aspect-[4/5] object-cover shadow-2xl"
              alt="Atendimento"
              loading="lazy"
              decoding="async"
            />
          </div>
          <div className="flex-1">
            <span className="text-[10px] uppercase tracking-[0.3em] text-gray-400 font-bold block mb-4">Metodologia</span>
            <h2 className="text-4xl font-serif mb-8 leading-tight">Foco em Resultados, Baseado em Relacionamento.</h2>
            <p className="text-gray-600 text-lg mb-8 leading-relaxed">
              Diferente de imobiliárias tradicionais, trabalhamos com um volume limitado de clientes. Isso nos permite dedicar tempo integral para entender cada detalhe da sua busca ou do seu imóvel à venda.
            </p>
            <ul className="space-y-6 mb-12">
              {[
                'Relatórios mensais de performance de venda.',
                'Acesso a imóveis "Off-Market" (não listados publicamente).',
                'Estratégia digital personalizada para cada propriedade.'
              ].map((item, idx) => (
                <li key={idx} className="flex gap-4 items-center font-medium">
                  <div className="w-2 h-2 bg-black rounded-full" />
                  {item}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => onNavigate('contact')}
              className="px-12 py-5 bg-black text-white text-[10px] font-display font-medium uppercase tracking-[0.2em] hover:bg-neutral-800 transition-all rounded-sm shadow-xl"
            >
              Agendar Consultoria
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
