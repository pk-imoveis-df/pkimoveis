
import React, { useState, useEffect } from 'react';
import { Property, SearchFilters } from '../types';
import PropertyCard from '../components/PropertyCard';
import Testimonials from '../components/Testimonials';
import SEO from '../components/SEO';
import { optimizeUnsplashUrl } from '../services/imageService';
import { ChevronRight, ChevronLeft, Search, Shield, Award, Map, Star, Plus, Minus } from 'lucide-react';

interface HomeProps {
  properties: Property[];
  onSelectProperty: (id: string) => void;
  onNavigateToProperties: (filters?: SearchFilters) => void;
  onNavigate: (page: string) => void;
}

const Home: React.FC<HomeProps> = ({ properties, onSelectProperty, onNavigateToProperties, onNavigate }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  
  const heroSlides = [
    {
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1920',
      title: 'Residências de Alto Padrão',
      subtitle: 'Onde o luxo e o design se encontram em perfeita harmonia.'
    },
    {
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1920',
      title: 'Arquitetura de Assinatura',
      subtitle: 'Projetos desenhados pelos maiores nomes do país.'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  const [searchState, setSearchState] = useState<SearchFilters>( {
    type: '',
    minPrice: 0,
    maxPrice: 0,
    location: '',
    city: '',
    state: '',
    bedrooms: 0,
    bathrooms: 0,
    parkingSpots: 0
  });

  const featuredProperties = properties.filter(p => p.featured).slice(0, 8);

  const faqs = [
    { q: 'Como agendar uma visita presencial?', a: 'Você pode agendar diretamente pela página do imóvel clicando em "Agendar Visita" ou via nosso WhatsApp oficial. Nossos consultores entrarão em contato para validar o horário.' },
    { q: 'Quais os critérios para listar meu imóvel?', a: 'Realizamos uma curadoria rigorosa baseada em localização, padrão construtivo e valor de mercado acima de R$ 2.000.000 para garantir a qualidade do nosso portfólio.' },
    { q: 'Trabalham com imóveis internacionais?', a: 'Sim, possuímos parcerias estratégicas em Miami, Lisboa e Dubai para clientes que buscam diversificação de patrimônio no exterior.' },
    { q: 'Como funciona a avaliação de imóvel?', a: 'Nossa avaliação é técnica e comparativa, levando em conta não apenas o m² da região, mas o valor agregado do projeto e acabamentos.' }
  ];

  return (
    <div className="bg-white">
      <SEO 
        title="Início" 
        description="Descubra imóveis ideais para morar ou investir: opções de casas, apartamentos e imóveis comerciais para comprar, vender ou alugar com a Parkimóveis."
      />
      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden">
        {heroSlides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="absolute inset-0 bg-black/40 z-10" />
            <img 
              src={slide.image} 
              alt={slide.title}
              className="w-full h-full object-cover scale-105"
              decoding="async"
              {...(index === 0 ? { fetchPriority: 'high' } : {})}
            />
            <div className="absolute inset-0 z-20 flex flex-col justify-center items-center text-center px-6">
              <h1 className="text-white text-5xl md:text-8xl font-serif mb-6 transform transition-transform duration-1000 leading-none">
                {slide.title}
              </h1>
              <p className="text-white/80 text-base md:text-lg tracking-[0.3em] uppercase font-display font-medium mb-12 max-w-2xl">
                {slide.subtitle}
              </p>
              <div className="flex flex-col md:flex-row gap-6">
                <button 
                  onClick={() => onNavigateToProperties()}
                  className="px-12 py-5 bg-white text-black uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-neutral-200 transition-all rounded-sm"
                >
                  Ver Imóveis
                </button>
                <button 
                  onClick={() => onNavigate('contact')}
                  className="px-12 py-5 border border-white text-white uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-white hover:text-black transition-all rounded-sm"
                >
                  Solicitar Orçamento
                </button>
              </div>
            </div>
          </div>
        ))}
        
        {/* Carousel Controls */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex gap-4">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-12 h-1.5 transition-all ${
                index === currentSlide ? 'bg-white w-20' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Smart Search Bar */}
      <section className="relative z-40 -mt-16 container mx-auto px-6">
        <div className="bg-white p-8 md:p-12 shadow-2xl flex flex-col md:flex-row gap-6 items-end rounded-sm">
          <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="flex flex-col gap-2">
              <label className="text-[10px] uppercase tracking-widest text-gray-400 font-display font-bold">Tipo de Imóvel</label>
              <select 
                className="bg-transparent border-b border-gray-200 py-2 focus:outline-none focus:border-black font-display font-semibold text-sm"
                onChange={(e) => setSearchState({...searchState, type: e.target.value})}
              >
                <option value="">Todos os tipos</option>
                <option value="Casa">Casa</option>
                <option value="Apartamento">Apartamento</option>
                <option value="Cobertura">Cobertura</option>
                <option value="Mansão">Mansão</option>
              </select>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-[10px] uppercase tracking-widest text-gray-400 font-display font-bold">Preço Mínimo</label>
              <select 
                className="bg-transparent border-b border-gray-200 py-2 focus:outline-none focus:border-black font-display font-semibold text-sm"
                onChange={(e) => setSearchState({...searchState, minPrice: Number(e.target.value)})}
              >
                <option value="0">Sem limite</option>
                <option value="2000000">R$ 2 Milhões</option>
                <option value="5000000">R$ 5 Milhões</option>
                <option value="10000000">R$ 10 Milhões</option>
                <option value="20000000">R$ 20 Milhões</option>
              </select>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-[10px] uppercase tracking-widest text-gray-400 font-display font-bold">Preço Máximo</label>
              <select 
                className="bg-transparent border-b border-gray-200 py-2 focus:outline-none focus:border-black font-display font-semibold text-sm"
                onChange={(e) => setSearchState({...searchState, maxPrice: Number(e.target.value)})}
              >
                <option value="0">Sem limite</option>
                <option value="5000000">Até 5 Milhões</option>
                <option value="10000000">Até 10 Milhões</option>
                <option value="20000000">Até 20 Milhões</option>
                <option value="50000000">Até 50 Milhões</option>
              </select>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-[10px] uppercase tracking-widest text-gray-400 font-display font-bold">Localização</label>
              <input 
                type="text" 
                placeholder="Ex: São Paulo, RJ..."
                className="bg-transparent border-b border-gray-200 py-2 focus:outline-none focus:border-black font-display font-semibold text-sm"
                onChange={(e) => setSearchState({...searchState, location: e.target.value})}
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-[10px] uppercase tracking-widest text-gray-400 font-display font-bold">Bairro</label>
              <input 
                type="text" 
                placeholder="Ex: Jardins, Leblon..."
                className="bg-transparent border-b border-gray-200 py-2 focus:outline-none focus:border-black font-display font-semibold text-sm"
              />
            </div>
          </div>
          <button 
            onClick={() => onNavigateToProperties(searchState)}
            className="w-full md:w-auto bg-black text-white px-12 py-5 flex items-center justify-center gap-3 uppercase tracking-[0.2em] text-[10px] font-display font-medium hover:bg-neutral-800 transition-all rounded-sm"
          >
            <Search size={18} />
            Buscar
          </button>
        </div>
      </section>

      {/* Differentials */}
      <section className="py-24 container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-center">
          {[
            { icon: <Shield size={40} strokeWidth={1} />, title: 'Segurança Total', desc: 'Monitoramento 24h e infraestrutura de proteção.' },
            { icon: <Award size={40} strokeWidth={1} />, title: 'Curadoria Elite', desc: 'Apenas imóveis com alto padrão de excelência.' },
            { icon: <Map size={40} strokeWidth={1} />, title: 'Localizações Prime', desc: 'Os bairros mais nobres e desejados do país.' },
            { icon: <Star size={40} strokeWidth={1} />, title: 'Experiência 5 Estrelas', desc: 'Atendimento personalizado e concierge imobiliário.' }
          ].map((item, idx) => (
            <div key={idx} className="flex flex-col items-center group">
              <div className="mb-6 p-6 border border-gray-100 rounded-full group-hover:border-black transition-all">
                {item.icon}
              </div>
              <h3 className="text-2xl font-serif mb-3 tracking-tight">{item.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-24 bg-neutral-50">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
              <span className="text-[10px] uppercase tracking-[0.4em] text-gray-400 font-display font-black block mb-4">Seleção Especial</span>
              <h2 className="text-5xl md:text-6xl font-serif leading-tight">Imóveis em Destaque</h2>
            </div>
            <button 
              onClick={() => onNavigateToProperties()}
              className="flex items-center gap-3 group text-[10px] uppercase tracking-[0.2em] font-display font-bold border-b border-black pb-2"
            >
              Ver todos os imóveis
              <ChevronRight className="transition-transform group-hover:translate-x-1" size={16} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {featuredProperties.map((property) => (
              <PropertyCard 
                key={property.id} 
                property={property} 
                onClick={onSelectProperty} 
              />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />

      {/* CTA Section with Gray Background */}
      <section className="relative py-24 md:py-32 overflow-hidden bg-neutral-800">
        <div className="container mx-auto px-10 relative z-10 flex flex-col md:flex-row items-center justify-between gap-10 md:gap-20">
          <div className="text-center md:text-left">
            {/* Minimalist Heading - Single line on desktop (md:whitespace-nowrap) */}
            <h2 className="text-white text-3xl md:text-4xl lg:text-5xl font-display font-light mb-4 leading-tight tracking-tight md:whitespace-nowrap">
              Gostaria de vender ou alugar seu imóvel?
            </h2>
            <p className="text-white/80 text-sm md:text-base uppercase tracking-[0.25em] font-display font-medium">
              Solicite um atendimento exclusivo com nossos especialistas
            </p>
          </div>
          <button 
            onClick={() => onNavigate('contact')}
            className="shrink-0 bg-[#f1f3f5] text-[#343a40] px-12 py-6 uppercase tracking-[0.2em] font-display font-bold text-[10px] hover:bg-white transition-all rounded-sm shadow-2xl transform hover:scale-105"
          >
            FALE COM ESPECIALISTA
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 container mx-auto px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-[10px] uppercase tracking-[0.4em] text-gray-400 font-display font-black block mb-4">FAQ</span>
            <h2 className="text-5xl font-serif leading-tight">Dúvidas Frequentes</h2>
          </div>
          
          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div key={idx} className="border-b border-gray-100 pb-4">
                <button 
                  className="w-full py-5 flex justify-between items-center text-left group"
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                >
                  <span className="text-xl font-serif tracking-tight group-hover:text-gray-600 transition-colors">{faq.q}</span>
                  {activeFaq === idx ? <Minus size={20} /> : <Plus size={20} />}
                </button>
                <div className={`overflow-hidden transition-all duration-300 ${activeFaq === idx ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
                  <p className="text-gray-500 pb-6 leading-relaxed font-medium">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
