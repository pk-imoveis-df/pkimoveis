
import { createClient } from '@supabase/supabase-js';

// Default values for development/preview if env vars are missing
const DEFAULT_SUPABASE_URL = 'https://uiqdjxgtqeisciacsgga.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVpcWRqeGd0cWVpc2NpYWNzZ2dhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyMjAwMTcsImV4cCI6MjA4Nzc5NjAxN30.sYYPsUfRnbqnuwVdUpmR0IS9z1PohPlPYbmqYUsodVQ';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || DEFAULT_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase URL or Anon Key is missing. Please check your environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

/**
 * Realiza o upload de uma imagem para o bucket do Supabase.
 * IMPORTANTE: No painel do Supabase, vá em 'Storage', crie um bucket chamado 'properties'
 * e marque-o como 'Public'.
 */
export const uploadImage = async (file: File | string, bucket: string = 'properties') => {
  if (!supabase) {
    throw new Error("Cliente Supabase não inicializado.");
  }

  let fileBody: Blob | File;
  let contentType = 'image/png';

  try {
    if (typeof file === 'string' && file.startsWith('data:')) {
      const parts = file.split(';base64,');
      const mimeMatch = parts[0].match(/:(.*?);/);
      contentType = mimeMatch ? mimeMatch[1] : 'image/png';
      
      const raw = window.atob(parts[1]);
      const rawLength = raw.length;
      const uInt8Array = new Uint8Array(rawLength);
      for (let i = 0; i < rawLength; ++i) {
        uInt8Array[i] = raw.charCodeAt(i);
      }
      fileBody = new Blob([uInt8Array], { type: contentType });
    } else {
      fileBody = file as File;
      contentType = (file as File).type;
    }

    const fileExt = contentType.split('/')[1] || 'png';
    const fileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(fileName, fileBody, {
        contentType: contentType,
        cacheControl: '3600',
        upsert: false
      });

    if (error) {
      // Tratamento específico para bucket não encontrado
      if (error.message.includes('not found') || (error as any).status === 404) {
        throw new Error(`O bucket '${bucket}' não existe. Crie-o no painel do Supabase > Storage > New Bucket.`);
      }
      throw error;
    }

    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return publicUrl;
  } catch (err: any) {
    console.error("Erro no upload:", err);
    throw new Error(err.message || "Falha ao processar imagem.");
  }
};
