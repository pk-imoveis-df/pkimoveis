<?php
/**
 * Funções e definições do Tema Park Imóveis
 */

function park_imoveis_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Registrar Menu Principal
    register_nav_menus(array(
        'primary' => 'Menu Principal Corporativo',
    ));
}
add_action('after_setup_theme', 'park_imoveis_setup');

// Registrar Custom Post Type: Imóvel
function register_property_cpt() {
    $labels = array(
        'name' => 'Imóveis',
        'singular_name' => 'Imóvel',
        'add_new' => 'Adicionar Ativo',
        'add_new_item' => 'Novo Ativo de Luxo',
        'edit_item' => 'Editar Propriedade',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'portfolio'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'menu_icon' => 'dashicons-admin-home',
        'show_in_rest' => true, // Habilita Gutenberg
    );
    register_post_type('property', $args);
}
add_action('init', 'register_property_cpt');

// Enfileirar Scripts e Tailwind
function park_imoveis_scripts() {
    wp_enqueue_style('park-style', get_stylesheet_uri());
    wp_enqueue_script('tailwind-cdn', 'https://cdn.tailwindcss.com', array(), null, false);
}
add_action('wp_enqueue_scripts', 'park_imoveis_scripts');

/**
 * Função auxiliar para pegar metadados formatados
 */
function get_property_meta($post_id) {
    return array(
        'preco' => get_post_meta($post_id, 'property_price', true),
        'area' => get_post_meta($post_id, 'property_area', true),
        'quartos' => get_post_meta($post_id, 'property_bedrooms', true),
        'banheiros' => get_post_meta($post_id, 'property_bathrooms', true),
        'vagas' => get_post_meta($post_id, 'property_parking', true),
        'cidade' => get_post_meta($post_id, 'property_city', true),
        'bairro' => get_post_meta($post_id, 'property_region', true),
    );
}
?>