
import { supabase, uploadImage } from '../supabaseClient';
import { Property, Inquiry } from '../types';

const mapProperty = (p: any): Property => ({
  id: p.id,
  code: p.code || '',
  title: p.title,
  description: p.description || '',
  price: Number(p.price),
  type: p.type,
  status: p.status,
  city: p.city || '',
  state: p.state || '',
  region: p.region || '',
  address: p.address || '',
  area: Number(p.area),
  bedrooms: p.bedrooms || 0,
  bathrooms: p.bathrooms || 0,
  parkingSpots: p.parking_spots || 0,
  mainImage: p.main_image,
  gallery: p.gallery || [],
  createdAt: p.created_at,
  featured: p.featured || false,
  lat: p.lat,
  lng: p.lng
});

export const propertyService = {
  async getAll(): Promise<Property[]> {
    if (!supabase) return [];
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(mapProperty);
  },

  async create(propertyData: Partial<Property>, mainImageFile: string | File, galleryFiles: (string | File)[] = []): Promise<Property> {
    if (!supabase) throw new Error("Supabase não configurado");
    
    // Upload main image
    const imageUrl = await uploadImage(mainImageFile);
    
    // Upload gallery images
    const galleryUrls = await Promise.all(
      galleryFiles.map(file => uploadImage(file))
    );

    // Prepare payload removing undefined values
    const payload: any = {
      code: propertyData.code,
      title: propertyData.title,
      description: propertyData.description,
      price: propertyData.price,
      type: propertyData.type,
      status: propertyData.status,
      city: propertyData.city,
      state: propertyData.state,
      region: propertyData.region,
      address: propertyData.address,
      area: propertyData.area,
      bedrooms: propertyData.bedrooms,
      bathrooms: propertyData.bathrooms,
      parking_spots: propertyData.parkingSpots,
      main_image: imageUrl,
      gallery: galleryUrls,
      featured: propertyData.featured
    };

    // Only add lat/lng if they are defined and valid numbers
    if (propertyData.lat !== undefined && propertyData.lat !== null) payload.lat = propertyData.lat;
    if (propertyData.lng !== undefined && propertyData.lng !== null) payload.lng = propertyData.lng;

    const { data, error } = await supabase
      .from('properties')
      .insert([payload])
      .select()
      .single();
      
    if (error) throw error;
    return mapProperty(data);
  },

  async deleteProperty(id: string): Promise<void> {
    if (!supabase) return;
    const { error } = await supabase.from('properties').delete().eq('id', id);
    if (error) throw error;
  },

  async submitInquiry(inquiry: Omit<Inquiry, 'id' | 'date'>): Promise<void> {
    if (!supabase) throw new Error("Supabase não configurado");
    const { error } = await supabase.from('inquiries').insert([{
      name: inquiry.name,
      email: inquiry.email,
      phone: inquiry.phone,
      message: inquiry.message,
      property_id: inquiry.propertyId
    }]);
    if (error) throw error;
  },

  async getInquiries(): Promise<any[]> {
    if (!supabase) return [];
    const { data, error } = await supabase
      .from('inquiries')
      .select('*, properties(title)')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async deleteInquiry(id: string): Promise<void> {
    if (!supabase) return;
    const { error } = await supabase.from('inquiries').delete().eq('id', id);
    if (error) throw error;
  }
};
