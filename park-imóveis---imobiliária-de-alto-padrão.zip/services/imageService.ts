
/**
 * Optimizes Unsplash URLs by adding format, quality, and sizing parameters.
 * @param url The original Unsplash URL
 * @param width Optional width parameter
 * @returns Optimized URL
 */
export const optimizeUnsplashUrl = (url: string, width?: number): string => {
  if (!url || !url.includes('images.unsplash.com')) return url;
  
  try {
    const urlObj = new URL(url);
    urlObj.searchParams.set('auto', 'format');
    urlObj.searchParams.set('q', '80');
    if (width) {
      urlObj.searchParams.set('w', width.toString());
      urlObj.searchParams.set('fit', 'crop');
    }
    return urlObj.toString();
  } catch (e) {
    return url;
  }
};
